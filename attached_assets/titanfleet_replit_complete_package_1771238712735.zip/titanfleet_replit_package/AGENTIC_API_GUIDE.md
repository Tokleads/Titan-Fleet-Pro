# 🤖 Agentic API Auto-Repair System

**AI-powered monitoring and automatic fixing of broken API integrations**

---

## 🎯 What This Does

Your TitanFleet customers connect external APIs (Resend, Stripe, Xero, etc.). When those APIs change or break:

1. **Detects failures** automatically (hourly health checks)
2. **AI diagnoses** the issue (fetches latest API docs, analyzes errors)
3. **Generates fixes** (writes code patches, config updates)
4. **Tests fixes** in sandbox before applying
5. **Learns from fixes** (builds knowledge base for future issues)
6. **Notifies admin** for approval (or auto-applies if enabled)

**Result:** Zero downtime from API changes. Your customers never notice when Resend updates their API.

---

## 🏗️ How It Works

### **1. Health Monitoring (Cron Job - Every Hour)**

```typescript
// Runs automatically every hour
await runAllHealthChecks();
```

**What it checks:**
- ✅ API authentication (keys still valid?)
- ✅ Endpoint availability (URLs working?)
- ✅ Response schema (fields changed?)
- ✅ Response time (degraded performance?)
- ✅ Error rates (spike in failures?)

**Monitored APIs:**
- Resend (email)
- Google Maps (geocoding, directions)
- Stripe (payments)
- Xero (accounting)
- QuickBooks (accounting)

### **2. Incident Detection**

When a health check fails:

```typescript
{
  apiType: 'resend',
  status: 'down',
  errorMessage: 'Invalid API key format',
  errorDetails: { statusCode: 401, ... }
}
```

**System creates an incident** and triggers the AI agent.

### **3. AI Agent Diagnosis**

```typescript
// Step 1: Fetch latest API documentation
const apiDocs = await fetchApiDocumentation('resend');

// Step 2: Analyze error with LLM
const diagnosis = await diagnoseApiError(incident, apiDocs);
```

**LLM analyzes:**
- Error message
- Error details (status codes, stack traces)
- Latest API documentation
- Historical fixes from knowledge base

**LLM provides:**
```json
{
  "diagnosis": "Resend API key format changed from 're_' to 'resend_'",
  "rootCause": "API v2 migration requires new key format",
  "recommendedActions": [
    "Update API key validation regex",
    "Migrate existing keys to new format",
    "Update documentation"
  ]
}
```

### **4. Fix Generation**

```typescript
const fix = await generateApiFix(incident, diagnosis, apiDocs);
```

**LLM generates:**
```json
{
  "description": "Update Resend API key validation to accept new format",
  "code": "// TypeScript code patch\nexport function validateResendKey(key: string) {\n  return /^resend_[a-zA-Z0-9]{32}$/.test(key);\n}",
  "type": "code_patch"
}
```

**Fix types:**
- `code_patch` - Update code (function changes, new endpoints)
- `config_update` - Update configuration (URLs, timeouts)
- `api_key_refresh` - Refresh authentication tokens

### **5. Sandbox Testing**

```typescript
const testResult = await testApiFix('resend', fix);
```

**System:**
1. Applies fix in isolated sandbox
2. Runs test API calls
3. Validates responses
4. Rolls back if test fails

### **6. Admin Approval**

Fix is stored as `pending_approval`:

```sql
INSERT INTO api_health_fixes (
  incident_id, diagnosis, fix_code, status
) VALUES (..., 'pending_approval');
```

**Admin dashboard shows:**
- AI diagnosis
- Generated code
- Test results
- Approve/Reject buttons

**If approved:**
- Fix is applied to production
- Incident is marked as resolved
- Fix is added to knowledge base

**If auto-fix enabled:**
- Fix is applied automatically (no approval needed)
- Admin is notified after application

### **7. Knowledge Base Learning**

```sql
INSERT INTO api_fix_knowledge_base (
  api_type, error_pattern, fix_template, success_count
) VALUES ('resend', 'Invalid API key format', '...', 1);
```

**Next time similar error occurs:**
- AI checks knowledge base first
- Applies proven fix immediately
- Skips diagnosis if confidence is high

---

## 📊 Database Schema

### **api_health_checks**
Logs every health check (hourly):
- api_type, status, response_time
- error_message, error_details
- checked_at

### **api_health_incidents**
Tracks API failures:
- api_type, status, severity
- error_message, failure_count
- detected_at, resolved_at

### **api_health_fixes**
AI-generated fixes:
- incident_id, diagnosis, fix_code
- status (pending_approval, approved, applied)
- test_result, approved_by

### **api_fix_knowledge_base**
Learning from past fixes:
- api_type, error_pattern, fix_template
- success_count, failure_count
- last_used_at

### **api_integration_settings**
Per-user API configurations:
- user_id, api_type, api_key
- auto_fix_enabled (allow AI to auto-apply)
- last_health_status

### **ai_agent_activity_log**
AI agent audit trail:
- activity_type (diagnosis, fix_generation, fix_test)
- llm_model, llm_tokens_used
- success, duration_ms

---

## 🚀 Setup Instructions

### **Step 1: Install Dependencies**

```bash
pnpm add node-cron
```

### **Step 2: Add Database Tables**

```bash
mysql -u root -p your_database < agentic_api_schema.sql
```

### **Step 3: Copy Files**

```bash
cp api_health_monitor.ts server/services/
cp ApiHealthDashboard.tsx client/src/pages/
```

### **Step 4: Set Up Cron Job**

```typescript
// server/index.ts or server/cron.ts
import cron from 'node-cron';
import { runAllHealthChecks } from './services/api_health_monitor';

// Run health checks every hour
cron.schedule('0 * * * *', async () => {
  console.log('[Cron] Running API health checks...');
  await runAllHealthChecks();
});
```

### **Step 5: Add tRPC Procedures**

```typescript
// server/routers.ts
import { apiHealthRouter } from './routers/apiHealth';

export const appRouter = router({
  // ... existing routers ...
  apiHealth: router(apiHealthRouter),
});
```

### **Step 6: Add Admin Route**

```typescript
// client/src/App.tsx
import ApiHealthDashboard from './pages/ApiHealthDashboard';

<Route path="/admin/api-health" element={<ApiHealthDashboard />} />
```

### **Step 7: Configure Environment Variables**

```bash
# .env
RESEND_TEST_API_KEY=re_...
GOOGLE_MAPS_API_KEY=AIza...
STRIPE_SECRET_KEY=sk_test_...
```

---

## 🎨 Admin Dashboard Features

### **Overview Tab**
- Real-time status cards for each API
- Response time metrics
- Last checked timestamps
- System health summary (healthy/degraded/down counts)

### **Incidents Tab**
- List of open incidents
- Severity badges (critical/warning)
- Error messages and details
- AI diagnosis (if available)
- Failure counts and timestamps

### **Pending Fixes Tab**
- AI-generated fixes awaiting approval
- Fix description and code preview
- Test results
- Approve/Reject buttons
- Code syntax highlighting

### **Analytics Tab**
- Total health checks (last 7 days)
- Incidents resolved by AI
- Average response time across APIs
- API uptime percentages
- Trend charts (optional)

---

## 🔧 Configuration Options

### **Per-User Auto-Fix Settings**

```typescript
// Allow AI to auto-apply fixes without approval
await db.update(apiIntegrationSettings)
  .set({ autoFixEnabled: true })
  .where(eq(apiIntegrationSettings.userId, userId));
```

**Recommended:**
- **Auto-fix OFF** for critical APIs (Stripe, payments)
- **Auto-fix ON** for non-critical APIs (Resend, Maps)

### **Health Check Frequency**

```typescript
// Default: Every hour
cron.schedule('0 * * * *', runAllHealthChecks);

// More frequent: Every 15 minutes
cron.schedule('*/15 * * * *', runAllHealthChecks);

// Less frequent: Every 6 hours
cron.schedule('0 */6 * * *', runAllHealthChecks);
```

### **LLM Model Selection**

```typescript
// In api_health_monitor.ts
const response = await invokeLLM({
  model: 'gpt-4', // Use GPT-4 for complex diagnoses
  messages: [...],
});
```

---

## 💡 Example Scenarios

### **Scenario 1: Resend API Key Format Change**

**What happens:**
1. **Hour 1:** Health check fails with "Invalid API key format"
2. **Hour 1 + 2min:** AI diagnoses: "Resend migrated to new key format"
3. **Hour 1 + 5min:** AI generates code patch to update validation regex
4. **Hour 1 + 6min:** Fix tested successfully in sandbox
5. **Hour 1 + 7min:** Admin receives notification
6. **Hour 1 + 10min:** Admin approves fix
7. **Hour 1 + 11min:** Fix applied to production
8. **Hour 2:** Health check passes ✅

**Without agentic system:**
- Customers report email failures
- You investigate error logs
- You read Resend changelog
- You write code fix
- You test manually
- You deploy fix
- **Total time: 2-4 hours** (or longer if you're asleep)

**With agentic system:**
- **Total time: 10 minutes** (or 0 minutes if auto-fix enabled)

### **Scenario 2: Google Maps API Endpoint Deprecated**

**What happens:**
1. Health check fails with "404 Not Found"
2. AI fetches latest Google Maps docs
3. AI finds: "Geocoding API moved from /geocode/json to /v2/geocode"
4. AI generates code patch to update endpoint URL
5. Fix tested and approved
6. Production updated

**Customer impact:** Zero downtime

### **Scenario 3: Stripe Rate Limit Exceeded**

**What happens:**
1. Health check shows "degraded" status (429 errors)
2. AI diagnoses: "Rate limit exceeded"
3. AI generates config update: Add exponential backoff + retry logic
4. Fix tested and approved
5. Production updated with retry mechanism

**Customer impact:** Payments succeed on retry instead of failing

---

## 📈 Benefits

### **1. Zero Downtime from API Changes**
- Customers never notice when external APIs update
- Fixes applied before customers report issues
- No manual monitoring required

### **2. Reduced Support Burden**
- Fewer "emails not sending" tickets
- Fewer "payment failed" complaints
- AI handles routine API maintenance

### **3. Competitive Advantage**
- **Your competitors:** Manual API fixes, 2-4 hour response time
- **You:** Automatic fixes, 10-minute response time (or instant with auto-fix)

### **4. Learning System**
- Knowledge base grows over time
- Future fixes get faster (AI learns from past fixes)
- Fixes can be shared across all customers

### **5. Cost Savings**
- Less developer time spent on API maintenance
- Fewer emergency deployments
- Reduced customer churn from API issues

---

## 🔒 Security Considerations

### **1. Sandbox Testing**
- All fixes tested in isolated environment
- No direct production access for AI
- Rollback if tests fail

### **2. Admin Approval**
- Critical APIs require manual approval
- Auto-fix only for low-risk integrations
- Audit trail for all AI actions

### **3. API Key Security**
- Keys encrypted in database
- Never logged or exposed in errors
- Separate test keys for health checks

### **4. Rate Limiting**
- Limit AI agent invocations (prevent abuse)
- Throttle health checks (respect API limits)
- Queue fixes (don't overwhelm LLM)

---

## 📊 Monitoring & Analytics

### **Track AI Agent Success Rate**

```sql
SELECT 
  activity_type,
  COUNT(*) as total,
  SUM(CASE WHEN success THEN 1 ELSE 0 END) as successful,
  ROUND(AVG(duration_ms), 2) as avg_duration_ms
FROM ai_agent_activity_log
WHERE created_at >= NOW() - INTERVAL 30 DAY
GROUP BY activity_type;
```

### **Most Common API Failures**

```sql
SELECT 
  api_type,
  COUNT(*) as incident_count,
  AVG(failure_count) as avg_failures_per_incident
FROM api_health_incidents
WHERE detected_at >= NOW() - INTERVAL 30 DAY
GROUP BY api_type
ORDER BY incident_count DESC;
```

### **Fix Success Rate by API**

```sql
SELECT 
  api_type,
  COUNT(*) as total_fixes,
  SUM(CASE WHEN status = 'applied' THEN 1 ELSE 0 END) as successful_fixes,
  ROUND(SUM(CASE WHEN status = 'applied' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as success_rate
FROM api_health_fixes
GROUP BY api_type;
```

---

## 🎯 Roadmap

### **Phase 1: Core System** ✅
- Health monitoring
- AI diagnosis
- Fix generation
- Admin approval workflow

### **Phase 2: Auto-Fix** (Next)
- Automatic fix application (no approval)
- Confidence scoring (only auto-apply high-confidence fixes)
- Rollback mechanism (undo if fix causes issues)

### **Phase 3: Predictive Monitoring** (Future)
- Predict API failures before they happen
- Proactive fixes (apply before API breaks)
- Trend analysis (detect degrading performance)

### **Phase 4: Multi-Tenant Learning** (Future)
- Share fixes across all TitanFleet customers
- Crowdsourced knowledge base
- Faster fixes for everyone

---

## 💰 Cost Analysis

### **LLM Usage Costs**

**Per incident:**
- Diagnosis: ~2,000 tokens ($0.02 with GPT-4)
- Fix generation: ~3,000 tokens ($0.03 with GPT-4)
- **Total per incident: ~$0.05**

**Monthly estimate:**
- 10 incidents/month × $0.05 = **$0.50/month**
- 100 incidents/month × $0.05 = **$5.00/month**

**ROI:**
- Manual fix time: 2 hours × $50/hour = **$100 per incident**
- AI fix time: 10 minutes × $50/hour = **$8.33 per incident**
- **Savings: $91.67 per incident**

**Break-even:** 1 incident per month

---

## ✅ What's Included

✅ **Health monitoring system** - Hourly checks for all APIs  
✅ **AI diagnosis engine** - Fetches docs, analyzes errors  
✅ **Fix generation** - Writes code patches automatically  
✅ **Sandbox testing** - Tests fixes before applying  
✅ **Admin dashboard** - Full UI for monitoring and approval  
✅ **Knowledge base** - Learns from past fixes  
✅ **Database schema** - Complete tables for tracking  
✅ **Audit trail** - Logs all AI agent activity  

---

## 🚀 Quick Start

1. **Copy files** to your project
2. **Run database migrations** (agentic_api_schema.sql)
3. **Set up cron job** (hourly health checks)
4. **Add admin route** (/admin/api-health)
5. **Configure test API keys** (for health checks)
6. **Enable auto-fix** (optional, for non-critical APIs)

**Estimated setup time:** 2-3 hours

**Result:** Your APIs are now self-healing. When Resend, Stripe, or Google Maps change their APIs, your system automatically detects, diagnoses, and fixes the issues—often before your customers even notice.

---

## 📚 Files Included

1. `api_health_monitor.ts` - Core monitoring and AI agent logic
2. `agentic_api_schema.sql` - Database tables
3. `ApiHealthDashboard.tsx` - Admin UI component
4. `AGENTIC_API_GUIDE.md` - This guide

---

**This is the future of SaaS reliability.** While your competitors manually fix broken API integrations, your system fixes itself. 🤖✨

-- Agentic API Health Monitoring Schema

-- API health checks log
CREATE TABLE api_health_checks (
  id VARCHAR(36) PRIMARY KEY,
  api_type VARCHAR(50) NOT NULL, -- resend, google_maps, stripe, etc.
  status VARCHAR(20) NOT NULL, -- healthy, degraded, down
  response_time INT NOT NULL, -- milliseconds
  error_message TEXT,
  error_details JSON,
  checked_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_api_checked (api_type, checked_at),
  INDEX idx_status (status)
);

-- API health incidents (when APIs fail)
CREATE TABLE api_health_incidents (
  id VARCHAR(36) PRIMARY KEY,
  api_type VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL, -- open, investigating, resolved, ignored
  severity VARCHAR(20) NOT NULL, -- critical, warning, info
  error_message TEXT NOT NULL,
  error_details JSON,
  failure_count INT DEFAULT 1,
  detected_at TIMESTAMP NOT NULL,
  last_failed_at TIMESTAMP NOT NULL,
  resolved_at TIMESTAMP,
  resolution_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_api_status (api_type, status),
  INDEX idx_detected (detected_at)
);

-- AI-generated fixes for API issues
CREATE TABLE api_health_fixes (
  id VARCHAR(36) PRIMARY KEY,
  incident_id VARCHAR(36) NOT NULL,
  api_type VARCHAR(50) NOT NULL,
  diagnosis TEXT NOT NULL, -- AI diagnosis of the issue
  fix_description TEXT NOT NULL, -- What the fix does
  fix_code TEXT NOT NULL, -- Generated code fix
  fix_type VARCHAR(50) NOT NULL, -- code_patch, config_update, api_key_refresh
  status VARCHAR(20) NOT NULL, -- pending_approval, approved, applied, failed, rejected
  tested_at TIMESTAMP,
  test_result JSON,
  approved_by VARCHAR(36), -- user_id who approved
  approved_at TIMESTAMP,
  applied_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (incident_id) REFERENCES api_health_incidents(id) ON DELETE CASCADE,
  INDEX idx_incident (incident_id),
  INDEX idx_status (status)
);

-- Knowledge base of API fixes (learning from past issues)
CREATE TABLE api_fix_knowledge_base (
  id VARCHAR(36) PRIMARY KEY,
  api_type VARCHAR(50) NOT NULL,
  error_pattern VARCHAR(500) NOT NULL, -- Regex pattern to match errors
  fix_template TEXT NOT NULL, -- Template for generating fixes
  success_count INT DEFAULT 0, -- How many times this fix worked
  failure_count INT DEFAULT 0,
  last_used_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_api_type (api_type),
  INDEX idx_success (success_count DESC)
);

-- API integration settings (per user)
CREATE TABLE api_integration_settings (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  api_type VARCHAR(50) NOT NULL,
  api_key TEXT, -- Encrypted
  api_secret TEXT, -- Encrypted
  config JSON, -- Additional config (endpoints, options, etc.)
  is_active BOOLEAN DEFAULT TRUE,
  auto_fix_enabled BOOLEAN DEFAULT FALSE, -- Allow AI to auto-apply fixes
  last_health_check TIMESTAMP,
  last_health_status VARCHAR(20), -- healthy, degraded, down
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_api (user_id, api_type),
  INDEX idx_user_id (user_id),
  INDEX idx_api_type (api_type)
);

-- API usage analytics (track API calls per user)
CREATE TABLE api_usage_analytics (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  api_type VARCHAR(50) NOT NULL,
  endpoint VARCHAR(255) NOT NULL,
  method VARCHAR(10) NOT NULL,
  status_code INT,
  response_time INT, -- milliseconds
  error_message TEXT,
  called_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_called (user_id, called_at),
  INDEX idx_api_called (api_type, called_at)
);

-- AI agent activity log
CREATE TABLE ai_agent_activity_log (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  incident_id VARCHAR(36),
  activity_type VARCHAR(50) NOT NULL, -- diagnosis, fix_generation, fix_test, fix_applied
  activity_details JSON NOT NULL,
  llm_model VARCHAR(50), -- Which LLM was used
  llm_tokens_used INT,
  success BOOLEAN NOT NULL,
  error_message TEXT,
  duration_ms INT, -- How long the activity took
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (incident_id) REFERENCES api_health_incidents(id) ON DELETE SET NULL,
  INDEX idx_incident (incident_id),
  INDEX idx_created (created_at)
);

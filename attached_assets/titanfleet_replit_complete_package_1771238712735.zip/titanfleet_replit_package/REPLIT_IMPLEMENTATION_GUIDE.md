# 🚀 TitanFleet API Integration - Replit Implementation Guide

## 📋 Overview

Implement a complete API integration system for TitanFleet that allows customers to connect external services (Resend, Stripe, Xero, QuickBooks, OpenStreetMap) and includes an agentic AI system that automatically monitors and fixes broken API integrations.

---

## 🎯 What You're Building

### **1. API Integration System**
- Customer-facing API key management UI
- Secure storage of API credentials
- Integration status monitoring
- Test connection functionality

### **2. Agentic Auto-Repair System**
- Hourly health checks for all connected APIs
- AI-powered diagnosis when APIs fail
- Automatic fix generation and testing
- Admin approval workflow
- Knowledge base that learns from fixes

### **3. Landing Page Updates**
- New "Integrations" section with company logos
- Visual showcase of supported integrations
- Authority building through brand recognition

---

## 📦 Files Provided

### **Backend:**
1. `api_health_monitor.ts` - Core monitoring and AI agent
2. `agentic_api_schema.sql` - Database tables
3. `email.ts` - Resend email integration service
4. `email_settings_schema.sql` - Email settings tables
5. `trpc_email_procedures.ts` - tRPC procedures for email
6. `trpc_api_health_procedures.ts` - tRPC procedures for health monitoring

### **Frontend:**
1. `ApiHealthDashboard.tsx` - Admin dashboard for monitoring
2. `EmailSettings.tsx` - Customer email settings UI
3. `IntegrationsPage.tsx` - Customer integrations management
4. `LandingPageIntegrations.tsx` - Landing page section

### **Documentation:**
1. `RESEND_INTEGRATION_GUIDE.md` - Email integration docs
2. `AGENTIC_API_GUIDE.md` - Auto-repair system docs

---

## 🏗️ Implementation Steps

### **Step 1: Database Setup (15 minutes)**

Run the SQL migrations to create all necessary tables:

```bash
# Navigate to your project
cd /path/to/titanfleet

# Run email settings migration
mysql -u root -p your_database < email_settings_schema.sql

# Run agentic API migration
mysql -u root -p your_database < agentic_api_schema.sql
```

**Tables created:**
- `email_settings` - User email configuration
- `email_logs` - Sent email tracking
- `api_health_checks` - Health check results
- `api_health_incidents` - API failure tracking
- `api_health_fixes` - AI-generated fixes
- `api_fix_knowledge_base` - Learning from past fixes
- `api_integration_settings` - Per-user API configs
- `api_usage_analytics` - API call tracking
- `ai_agent_activity_log` - AI agent audit trail

---

### **Step 2: Install Dependencies (5 minutes)**

```bash
pnpm add resend node-cron p-queue
```

**Dependencies:**
- `resend` - Email sending via Resend API
- `node-cron` - Scheduled health checks
- `p-queue` - Rate limiting for API calls

---

### **Step 3: Backend Integration (45 minutes)**

#### **3.1: Copy Service Files**

```bash
# Email service
cp email.ts server/services/

# API health monitor
cp api_health_monitor.ts server/services/
```

#### **3.2: Add tRPC Procedures**

Create `server/routers/email.ts`:
```typescript
import { router, protectedProcedure } from '../_core/trpc';
import * as emailProcedures from '../procedures/email';

export const emailRouter = router({
  getSettings: protectedProcedure.query(emailProcedures.getSettings),
  updateSettings: protectedProcedure.input(emailProcedures.updateSettingsSchema).mutation(emailProcedures.updateSettings),
  updatePreferences: protectedProcedure.input(emailProcedures.updatePreferencesSchema).mutation(emailProcedures.updatePreferences),
  sendTestEmail: protectedProcedure.input(emailProcedures.sendTestEmailSchema).mutation(emailProcedures.sendTestEmail),
  getEmailLogs: protectedProcedure.query(emailProcedures.getEmailLogs),
});
```

Create `server/routers/apiHealth.ts`:
```typescript
import { router, protectedProcedure, adminProcedure } from '../_core/trpc';
import * as apiHealthProcedures from '../procedures/apiHealth';

export const apiHealthRouter = router({
  getStatus: adminProcedure.query(apiHealthProcedures.getStatus),
  getIncidents: adminProcedure.query(apiHealthProcedures.getIncidents),
  getPendingFixes: adminProcedure.query(apiHealthProcedures.getPendingFixes),
  getAnalytics: adminProcedure.query(apiHealthProcedures.getAnalytics),
  runHealthCheck: adminProcedure.mutation(apiHealthProcedures.runHealthCheck),
  approveFix: adminProcedure.input(apiHealthProcedures.approveFixSchema).mutation(apiHealthProcedures.approveFix),
  rejectFix: adminProcedure.input(apiHealthProcedures.rejectFixSchema).mutation(apiHealthProcedures.rejectFix),
});
```

Update `server/routers.ts`:
```typescript
import { emailRouter } from './routers/email';
import { apiHealthRouter } from './routers/apiHealth';

export const appRouter = router({
  // ... existing routers ...
  email: emailRouter,
  apiHealth: apiHealthRouter,
});
```

#### **3.3: Set Up Cron Job**

Add to `server/index.ts` (or create `server/cron.ts`):

```typescript
import cron from 'node-cron';
import { runAllHealthChecks } from './services/api_health_monitor';

// Run API health checks every hour
cron.schedule('0 * * * *', async () => {
  console.log('[Cron] Running API health checks...');
  try {
    await runAllHealthChecks();
    console.log('[Cron] Health checks completed');
  } catch (error) {
    console.error('[Cron] Health check error:', error);
  }
});

console.log('[Cron] API health monitoring scheduled (hourly)');
```

#### **3.4: Add Environment Variables**

Update `.env`:
```bash
# Email Integration (Resend)
RESEND_API_KEY=re_your_key_here

# Stripe (if using)
STRIPE_SECRET_KEY=sk_test_your_key_here

# Xero (if using)
XERO_CLIENT_ID=your_client_id
XERO_CLIENT_SECRET=your_client_secret

# QuickBooks (if using)
QUICKBOOKS_CLIENT_ID=your_client_id
QUICKBOOKS_CLIENT_SECRET=your_client_secret
```

---

### **Step 4: Frontend Integration (60 minutes)**

#### **4.1: Copy React Components**

```bash
# Customer-facing pages
cp EmailSettings.tsx client/src/pages/
cp IntegrationsPage.tsx client/src/pages/

# Admin dashboard
cp ApiHealthDashboard.tsx client/src/pages/admin/

# Landing page section
cp LandingPageIntegrations.tsx client/src/components/
```

#### **4.2: Add Routes**

Update `client/src/App.tsx`:

```typescript
import EmailSettings from './pages/EmailSettings';
import IntegrationsPage from './pages/IntegrationsPage';
import ApiHealthDashboard from './pages/admin/ApiHealthDashboard';

// Inside your routes:
<Route path="/settings/email" element={<EmailSettings />} />
<Route path="/settings/integrations" element={<IntegrationsPage />} />
<Route path="/admin/api-health" element={<ApiHealthDashboard />} />
```

#### **4.3: Update Navigation**

Add to dashboard sidebar or settings menu:

```typescript
// Settings menu
<NavItem to="/settings/email" icon={Mail}>Email Notifications</NavItem>
<NavItem to="/settings/integrations" icon={Plug}>Integrations</NavItem>

// Admin menu (only for admins)
{user?.role === 'admin' && (
  <NavItem to="/admin/api-health" icon={Activity}>API Health</NavItem>
)}
```

#### **4.4: Update Landing Page**

Add integrations section to `client/src/pages/Home.tsx`:

```typescript
import LandingPageIntegrations from '@/components/LandingPageIntegrations';

// Inside your landing page:
<LandingPageIntegrations />
```

---

### **Step 5: Logo Assets (30 minutes)**

#### **5.1: Download Company Logos**

Download official logos from:
- **Resend:** https://resend.com/brand
- **Stripe:** https://stripe.com/newsroom/brand-assets
- **Xero:** https://www.xero.com/uk/about/media/
- **QuickBooks:** https://quickbooks.intuit.com/press-room/
- **OpenStreetMap:** https://wiki.openstreetmap.org/wiki/Logo

#### **5.2: Save Logos**

```bash
# Create integrations directory
mkdir -p client/public/integrations

# Save logos (SVG preferred, PNG as fallback)
client/public/integrations/
  ├── resend-logo.svg
  ├── stripe-logo.svg
  ├── xero-logo.svg
  ├── quickbooks-logo.svg
  └── openstreetmap-logo.svg
```

#### **5.3: Logo Usage Guidelines**

**Resend:**
- Use dark logo on light backgrounds
- Minimum width: 100px
- Clear space: 20px around logo

**Stripe:**
- Use purple logo (#635BFF)
- Minimum height: 28px
- Clear space: Equal to height of logo

**Xero:**
- Use blue logo (#13B5EA)
- Minimum width: 80px
- Don't modify or distort

**QuickBooks:**
- Use green logo (#2CA01C)
- Minimum width: 100px
- Don't alter colors

**OpenStreetMap:**
- Use official logo with magnifying glass
- Minimum width: 80px
- Include attribution if required

---

### **Step 6: Testing (30 minutes)**

#### **6.1: Test Email Integration**

1. Navigate to `/settings/email`
2. Add Resend API key
3. Configure from address
4. Send test email
5. Check email logs

#### **6.2: Test API Health Monitoring**

1. Navigate to `/admin/api-health`
2. Click "Run Health Check"
3. Verify all APIs show status
4. Check response times

#### **6.3: Test Auto-Fix (Simulated)**

1. Temporarily break an API (invalid key)
2. Wait for health check (or trigger manually)
3. Verify incident is created
4. Check if AI generates fix
5. Approve fix in dashboard

---

## 🎨 Landing Page Design

### **Integrations Section Layout**

```
┌─────────────────────────────────────────────┐
│  Seamless Integrations                      │
│  Connect TitanFleet with your favorite      │
│  tools and services                         │
│                                             │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  │
│  │Resend│  │Stripe│  │ Xero │  │ QB   │  │
│  └──────┘  └──────┘  └──────┘  └──────┘  │
│  ┌──────┐                                  │
│  │ OSM  │                                  │
│  └──────┘                                  │
│                                             │
│  [View All Integrations →]                 │
└─────────────────────────────────────────────┘
```

### **Key Features to Highlight**

✅ **Email Notifications** - Automated delivery updates via Resend  
✅ **Payment Processing** - Secure payments through Stripe  
✅ **Accounting Sync** - Connect to Xero or QuickBooks  
✅ **Route Optimization** - Powered by OpenStreetMap  
✅ **API Access** - Full REST API for custom integrations  

---

## 🔒 Security Checklist

### **Before Going Live:**

- [ ] API keys encrypted in database
- [ ] Environment variables not committed to git
- [ ] Rate limiting enabled on API endpoints
- [ ] Admin-only access to API health dashboard
- [ ] CORS configured correctly
- [ ] Input validation on all API key fields
- [ ] Audit logging for API key changes
- [ ] Sandbox testing for AI-generated fixes
- [ ] Error messages don't expose sensitive data
- [ ] API keys never logged or exposed in errors

---

## 📊 Success Metrics

### **Track These Metrics:**

1. **Integration Adoption**
   - % of users who connect at least one integration
   - Most popular integrations
   - Time to first integration

2. **API Health**
   - Uptime percentage per API
   - Average response time
   - Number of incidents detected

3. **Auto-Fix Performance**
   - % of incidents auto-fixed
   - Time to fix (detection → resolution)
   - Fix success rate

4. **Customer Impact**
   - Reduction in support tickets
   - Customer satisfaction scores
   - Churn rate (before/after integrations)

---

## 🐛 Troubleshooting

### **Common Issues:**

**Issue:** Health checks not running
- **Solution:** Check cron job is started in `server/index.ts`
- **Verify:** `console.log` should show "[Cron] API health monitoring scheduled"

**Issue:** Email not sending
- **Solution:** Verify Resend API key is valid
- **Check:** Navigate to `/settings/email` and send test email

**Issue:** AI agent not generating fixes
- **Solution:** Check LLM integration is working
- **Verify:** `invokeLLM` function has valid API key

**Issue:** Logos not displaying
- **Solution:** Check file paths in `client/public/integrations/`
- **Verify:** Logos are accessible at `/integrations/resend-logo.svg`

---

## 🚀 Deployment Checklist

### **Before Deploying:**

- [ ] All database migrations run successfully
- [ ] Environment variables set in production
- [ ] Cron job scheduled and running
- [ ] All routes accessible
- [ ] Logos displaying correctly on landing page
- [ ] Email integration tested
- [ ] API health dashboard accessible (admin only)
- [ ] Security checklist completed
- [ ] Error monitoring configured
- [ ] Backup strategy in place

---

## 📚 Additional Resources

### **API Documentation:**
- Resend: https://resend.com/docs
- Stripe: https://stripe.com/docs/api
- Xero: https://developer.xero.com/documentation
- QuickBooks: https://developer.intuit.com/app/developer/qbo/docs
- OpenStreetMap: https://wiki.openstreetmap.org/wiki/API

### **Logo Guidelines:**
- Resend Brand: https://resend.com/brand
- Stripe Brand: https://stripe.com/newsroom/brand-assets
- Xero Brand: https://www.xero.com/uk/about/media/
- QuickBooks Brand: https://quickbooks.intuit.com/press-room/
- OSM Logo: https://wiki.openstreetmap.org/wiki/Logo

---

## 💡 Pro Tips

1. **Start with email integration** - It's the easiest and most valuable
2. **Test health checks manually first** - Before relying on cron
3. **Use staging environment** - Test AI fixes before production
4. **Monitor LLM costs** - Track token usage for AI agent
5. **Gather customer feedback** - Which integrations do they want most?

---

## ✅ Definition of Done

Integration is complete when:

- [ ] Customer can add Resend API key and send emails
- [ ] Landing page displays integration logos
- [ ] API health checks run hourly
- [ ] Admin can view API health dashboard
- [ ] AI agent generates fixes for failures
- [ ] Admin can approve/reject fixes
- [ ] All tests pass
- [ ] Documentation updated
- [ ] Security review completed
- [ ] Deployed to production

---

## 🎯 Estimated Time

- **Database setup:** 15 minutes
- **Backend integration:** 45 minutes
- **Frontend integration:** 60 minutes
- **Logo assets:** 30 minutes
- **Testing:** 30 minutes
- **Documentation:** 15 minutes

**Total: ~3 hours**

---

## 🆘 Need Help?

If you encounter issues:

1. Check the troubleshooting section above
2. Review the detailed guides:
   - `RESEND_INTEGRATION_GUIDE.md`
   - `AGENTIC_API_GUIDE.md`
3. Verify all environment variables are set
4. Check database migrations ran successfully
5. Review console logs for errors

---

**Good luck! You're building something awesome.** 🚀

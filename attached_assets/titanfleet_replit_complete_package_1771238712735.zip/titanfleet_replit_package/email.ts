/**
 * Email Service - Resend Integration
 * Sends automated emails for deliveries, POD, maintenance, etc.
 */

import { Resend } from 'resend';
import { db } from '../db';
import { userSettings } from '../schema';
import { eq } from 'drizzle-orm';

/**
 * Get user's Resend configuration
 */
async function getResendClient(userId: string): Promise<Resend | null> {
  const [settings] = await db
    .select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);

  if (!settings?.resendApiKey) {
    console.log(`No Resend API key configured for user ${userId}`);
    return null;
  }

  return new Resend(settings.resendApiKey);
}

/**
 * Get user's email settings
 */
async function getEmailSettings(userId: string) {
  const [settings] = await db
    .select()
    .from(userSettings)
    .where(eq(userSettings.userId, userId))
    .limit(1);

  return {
    fromAddress: settings?.emailFromAddress || 'notifications@titanfleet.co.uk',
    fromName: settings?.emailFromName || 'TitanFleet',
    replyTo: settings?.emailReplyTo || null,
  };
}

/**
 * Send delivery completion notification
 */
export async function sendDeliveryCompletedEmail(
  userId: string,
  delivery: any,
  pod: any
): Promise<boolean> {
  try {
    const resend = await getResendClient(userId);
    if (!resend) return false;

    const settings = await getEmailSettings(userId);

    // Format completion time
    const completedTime = new Date(pod.completedAt).toLocaleString('en-GB', {
      dateStyle: 'full',
      timeStyle: 'short',
    });

    await resend.emails.send({
      from: `${settings.fromName} <${settings.fromAddress}>`,
      to: delivery.customerEmail || delivery.customerName,
      replyTo: settings.replyTo || undefined,
      subject: `✅ Delivery Completed - ${delivery.referenceNumber || 'Order'}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
            .content { background: #f9fafb; padding: 20px; }
            .detail { margin: 10px 0; }
            .label { font-weight: bold; color: #6b7280; }
            .signature { margin-top: 20px; border: 1px solid #d1d5db; padding: 10px; }
            .footer { text-align: center; color: #6b7280; font-size: 12px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>✅ Delivery Completed</h1>
            </div>
            <div class="content">
              <p>Your delivery has been successfully completed.</p>
              
              <div class="detail">
                <span class="label">Reference:</span> ${delivery.referenceNumber || 'N/A'}
              </div>
              
              <div class="detail">
                <span class="label">Delivery Address:</span><br>
                ${delivery.deliveryAddress}<br>
                ${delivery.deliveryPostcode}
              </div>
              
              <div class="detail">
                <span class="label">Completed:</span> ${completedTime}
              </div>
              
              <div class="detail">
                <span class="label">Received By:</span> ${pod.recipientName}
              </div>
              
              ${pod.notes ? `
              <div class="detail">
                <span class="label">Notes:</span> ${pod.notes}
              </div>
              ` : ''}
              
              ${pod.signatureImageUrl ? `
              <div class="signature">
                <div class="label">Signature:</div>
                <img src="${pod.signatureImageUrl}" alt="Recipient Signature" style="max-width: 300px; margin-top: 10px;">
              </div>
              ` : ''}
              
              ${pod.photoUrl ? `
              <div class="signature">
                <div class="label">Proof of Delivery Photo:</div>
                <img src="${pod.photoUrl}" alt="Delivery Photo" style="max-width: 100%; margin-top: 10px;">
              </div>
              ` : ''}
              
              <div class="detail" style="margin-top: 20px;">
                <span class="label">GPS Location:</span><br>
                <a href="https://www.google.com/maps?q=${pod.gpsLat},${pod.gpsLng}" target="_blank">
                  View on Map (${pod.gpsLat}, ${pod.gpsLng})
                </a>
              </div>
            </div>
            
            <div class="footer">
              <p>This is an automated notification from TitanFleet.</p>
              ${settings.replyTo ? `<p>Questions? Reply to this email or contact ${settings.replyTo}</p>` : ''}
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log(`Delivery completion email sent for delivery ${delivery.id}`);
    return true;
  } catch (error) {
    console.error('Error sending delivery completion email:', error);
    return false;
  }
}

/**
 * Send delivery created notification
 */
export async function sendDeliveryCreatedEmail(
  userId: string,
  delivery: any
): Promise<boolean> {
  try {
    const resend = await getResendClient(userId);
    if (!resend) return false;

    const settings = await getEmailSettings(userId);

    const scheduledTime = new Date(delivery.deliveryScheduledAt).toLocaleString('en-GB', {
      dateStyle: 'full',
      timeStyle: 'short',
    });

    await resend.emails.send({
      from: `${settings.fromName} <${settings.fromAddress}>`,
      to: delivery.customerEmail || delivery.customerName,
      replyTo: settings.replyTo || undefined,
      subject: `📦 Delivery Scheduled - ${delivery.referenceNumber || 'Order'}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
            .content { background: #f9fafb; padding: 20px; }
            .detail { margin: 10px 0; }
            .label { font-weight: bold; color: #6b7280; }
            .footer { text-align: center; color: #6b7280; font-size: 12px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>📦 Delivery Scheduled</h1>
            </div>
            <div class="content">
              <p>Your delivery has been scheduled.</p>
              
              <div class="detail">
                <span class="label">Reference:</span> ${delivery.referenceNumber || 'N/A'}
              </div>
              
              <div class="detail">
                <span class="label">Scheduled Delivery:</span> ${scheduledTime}
              </div>
              
              <div class="detail">
                <span class="label">Delivery Address:</span><br>
                ${delivery.deliveryAddress}<br>
                ${delivery.deliveryPostcode}
              </div>
              
              ${delivery.notes ? `
              <div class="detail">
                <span class="label">Notes:</span> ${delivery.notes}
              </div>
              ` : ''}
              
              <p style="margin-top: 20px;">You will receive another notification when the delivery is completed.</p>
            </div>
            
            <div class="footer">
              <p>This is an automated notification from TitanFleet.</p>
              ${settings.replyTo ? `<p>Questions? Reply to this email or contact ${settings.replyTo}</p>` : ''}
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log(`Delivery created email sent for delivery ${delivery.id}`);
    return true;
  } catch (error) {
    console.error('Error sending delivery created email:', error);
    return false;
  }
}

/**
 * Send maintenance due reminder
 */
export async function sendMaintenanceDueEmail(
  userId: string,
  vehicle: any,
  maintenance: any
): Promise<boolean> {
  try {
    const resend = await getResendClient(userId);
    if (!resend) return false;

    const settings = await getEmailSettings(userId);

    const dueDate = new Date(maintenance.nextDueAt).toLocaleDateString('en-GB', {
      dateStyle: 'full',
    });

    // Get user's email from settings
    const [userSettings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, userId))
      .limit(1);

    if (!userSettings?.notificationEmail) {
      console.log('No notification email configured');
      return false;
    }

    await resend.emails.send({
      from: `${settings.fromName} <${settings.fromAddress}>`,
      to: userSettings.notificationEmail,
      replyTo: settings.replyTo || undefined,
      subject: `⚠️ Maintenance Due - ${vehicle.registration}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #f59e0b; color: white; padding: 20px; text-align: center; }
            .content { background: #f9fafb; padding: 20px; }
            .detail { margin: 10px 0; }
            .label { font-weight: bold; color: #6b7280; }
            .footer { text-align: center; color: #6b7280; font-size: 12px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>⚠️ Maintenance Due</h1>
            </div>
            <div class="content">
              <p>A maintenance service is due for one of your vehicles.</p>
              
              <div class="detail">
                <span class="label">Vehicle:</span> ${vehicle.registration}
              </div>
              
              <div class="detail">
                <span class="label">Make/Model:</span> ${vehicle.make} ${vehicle.model}
              </div>
              
              <div class="detail">
                <span class="label">Maintenance Type:</span> ${maintenance.maintenanceType}
              </div>
              
              <div class="detail">
                <span class="label">Due Date:</span> ${dueDate}
              </div>
              
              ${maintenance.nextDueMileage ? `
              <div class="detail">
                <span class="label">Due Mileage:</span> ${maintenance.nextDueMileage.toLocaleString()} miles
              </div>
              ` : ''}
              
              <p style="margin-top: 20px;">Please schedule this maintenance to keep your vehicle compliant and roadworthy.</p>
            </div>
            
            <div class="footer">
              <p>This is an automated reminder from TitanFleet.</p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log(`Maintenance due email sent for vehicle ${vehicle.id}`);
    return true;
  } catch (error) {
    console.error('Error sending maintenance due email:', error);
    return false;
  }
}

/**
 * Send vehicle defect alert
 */
export async function sendDefectAlertEmail(
  userId: string,
  vehicle: any,
  defect: any,
  driver: any
): Promise<boolean> {
  try {
    const resend = await getResendClient(userId);
    if (!resend) return false;

    const settings = await getEmailSettings(userId);

    const reportedTime = new Date(defect.reportedAt).toLocaleString('en-GB', {
      dateStyle: 'full',
      timeStyle: 'short',
    });

    // Get user's email
    const [userSettings] = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, userId))
      .limit(1);

    if (!userSettings?.notificationEmail) return false;

    const severityColor = {
      minor: '#10b981',
      major: '#f59e0b',
      dangerous: '#ef4444',
    }[defect.severity] || '#6b7280';

    await resend.emails.send({
      from: `${settings.fromName} <${settings.fromAddress}>`,
      to: userSettings.notificationEmail,
      replyTo: settings.replyTo || undefined,
      subject: `🚨 ${defect.severity.toUpperCase()} Defect Reported - ${vehicle.registration}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: ${severityColor}; color: white; padding: 20px; text-align: center; }
            .content { background: #f9fafb; padding: 20px; }
            .detail { margin: 10px 0; }
            .label { font-weight: bold; color: #6b7280; }
            .severity { display: inline-block; padding: 5px 10px; border-radius: 5px; background: ${severityColor}; color: white; font-weight: bold; }
            .footer { text-align: center; color: #6b7280; font-size: 12px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🚨 Vehicle Defect Reported</h1>
            </div>
            <div class="content">
              <p>A driver has reported a defect on one of your vehicles.</p>
              
              <div class="detail">
                <span class="label">Severity:</span> <span class="severity">${defect.severity.toUpperCase()}</span>
              </div>
              
              <div class="detail">
                <span class="label">Vehicle:</span> ${vehicle.registration}
              </div>
              
              <div class="detail">
                <span class="label">Category:</span> ${defect.category || 'General'}
              </div>
              
              <div class="detail">
                <span class="label">Reported By:</span> ${driver ? `${driver.firstName} ${driver.lastName}` : 'Unknown'}
              </div>
              
              <div class="detail">
                <span class="label">Reported:</span> ${reportedTime}
              </div>
              
              <div class="detail">
                <span class="label">Description:</span><br>
                ${defect.description}
              </div>
              
              ${defect.photoUrl ? `
              <div class="detail">
                <span class="label">Photo:</span><br>
                <img src="${defect.photoUrl}" alt="Defect Photo" style="max-width: 100%; margin-top: 10px;">
              </div>
              ` : ''}
              
              ${defect.severity === 'dangerous' ? `
              <p style="margin-top: 20px; padding: 15px; background: #fee2e2; border-left: 4px solid #ef4444;">
                <strong>⚠️ DANGEROUS DEFECT:</strong> This vehicle should not be driven until the defect is resolved.
              </p>
              ` : ''}
            </div>
            
            <div class="footer">
              <p>This is an automated alert from TitanFleet.</p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log(`Defect alert email sent for vehicle ${vehicle.id}`);
    return true;
  } catch (error) {
    console.error('Error sending defect alert email:', error);
    return false;
  }
}

/**
 * Test email configuration
 */
export async function sendTestEmail(
  userId: string,
  toEmail: string
): Promise<boolean> {
  try {
    const resend = await getResendClient(userId);
    if (!resend) {
      throw new Error('Resend API key not configured');
    }

    const settings = await getEmailSettings(userId);

    await resend.emails.send({
      from: `${settings.fromName} <${settings.fromAddress}>`,
      to: toEmail,
      replyTo: settings.replyTo || undefined,
      subject: '✅ TitanFleet Email Configuration Test',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #10b981; color: white; padding: 20px; text-align: center; }
            .content { background: #f9fafb; padding: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>✅ Email Configuration Successful</h1>
            </div>
            <div class="content">
              <p>Your TitanFleet email integration is working correctly!</p>
              <p>You will now receive automated notifications for:</p>
              <ul>
                <li>Delivery completions</li>
                <li>Maintenance reminders</li>
                <li>Vehicle defects</li>
                <li>Driver hours alerts</li>
              </ul>
              <p>You can customize these settings in your TitanFleet dashboard.</p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    return true;
  } catch (error) {
    console.error('Error sending test email:', error);
    throw error;
  }
}

/**
 * API Health Dashboard
 * Admin view for monitoring API health and approving AI-generated fixes
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Activity,
  AlertCircle,
  CheckCircle,
  Clock,
  Code,
  Loader2,
  RefreshCw,
  TrendingUp,
  XCircle,
  Zap,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function ApiHealthDashboard() {
  const { toast } = useToast();
  const [selectedIncident, setSelectedIncident] = useState<string | null>(null);

  // Queries
  const { data: healthStatus, refetch: refetchHealth } = trpc.apiHealth.getStatus.useQuery();
  const { data: incidents } = trpc.apiHealth.getIncidents.useQuery({ status: 'open' });
  const { data: fixes } = trpc.apiHealth.getPendingFixes.useQuery();
  const { data: analytics } = trpc.apiHealth.getAnalytics.useQuery({ days: 7 });

  // Mutations
  const runHealthCheck = trpc.apiHealth.runHealthCheck.useMutation({
    onSuccess: () => {
      toast({ title: 'Success', description: 'Health check completed' });
      refetchHealth();
    },
  });

  const approveFix = trpc.apiHealth.approveFix.useMutation({
    onSuccess: () => {
      toast({ title: 'Success', description: 'Fix approved and applied' });
      refetchHealth();
    },
    onError: (error) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  const rejectFix = trpc.apiHealth.rejectFix.useMutation({
    onSuccess: () => {
      toast({ title: 'Success', description: 'Fix rejected' });
    },
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'degraded':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      case 'down':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Activity className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'destructive' | 'secondary'> = {
      healthy: 'default',
      degraded: 'secondary',
      down: 'destructive',
    };
    return <Badge variant={variants[status] || 'secondary'}>{status}</Badge>;
  };

  return (
    <div className="container max-w-7xl py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Zap className="w-8 h-8" />
            API Health Monitor
          </h1>
          <p className="text-muted-foreground mt-2">
            AI-powered monitoring and auto-repair for API integrations
          </p>
        </div>
        <Button
          onClick={() => runHealthCheck.mutate()}
          disabled={runHealthCheck.isPending}
        >
          {runHealthCheck.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Run Health Check
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="incidents">
            Incidents
            {incidents && incidents.length > 0 && (
              <Badge variant="destructive" className="ml-2">
                {incidents.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="fixes">
            Pending Fixes
            {fixes && fixes.length > 0 && (
              <Badge variant="secondary" className="ml-2">
                {fixes.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {healthStatus?.apis.map((api: any) => (
              <Card key={api.type}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium">{api.name}</CardTitle>
                    {getStatusIcon(api.status)}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {getStatusBadge(api.status)}
                    <p className="text-xs text-muted-foreground">
                      Response: {api.responseTime}ms
                    </p>
                    {api.lastChecked && (
                      <p className="text-xs text-muted-foreground">
                        Last checked: {new Date(api.lastChecked).toLocaleTimeString()}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* System Health Summary */}
          <Card>
            <CardHeader>
              <CardTitle>System Health Summary</CardTitle>
              <CardDescription>Overall API integration health</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-green-500">
                    {healthStatus?.summary.healthy || 0}
                  </p>
                  <p className="text-sm text-muted-foreground">Healthy</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-yellow-500">
                    {healthStatus?.summary.degraded || 0}
                  </p>
                  <p className="text-sm text-muted-foreground">Degraded</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-red-500">
                    {healthStatus?.summary.down || 0}
                  </p>
                  <p className="text-sm text-muted-foreground">Down</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Incidents Tab */}
        <TabsContent value="incidents" className="space-y-6">
          {incidents && incidents.length > 0 ? (
            incidents.map((incident: any) => (
              <Card key={incident.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {incident.severity === 'critical' && (
                          <XCircle className="w-5 h-5 text-red-500" />
                        )}
                        {incident.severity === 'warning' && (
                          <AlertCircle className="w-5 h-5 text-yellow-500" />
                        )}
                        {incident.apiType} - {incident.status}
                      </CardTitle>
                      <CardDescription>
                        Detected: {new Date(incident.detectedAt).toLocaleString()}
                      </CardDescription>
                    </div>
                    <Badge
                      variant={incident.severity === 'critical' ? 'destructive' : 'secondary'}
                    >
                      {incident.severity}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="font-medium">Error Message:</p>
                    <p className="text-sm text-muted-foreground">{incident.errorMessage}</p>
                  </div>

                  {incident.errorDetails && (
                    <div>
                      <p className="font-medium">Error Details:</p>
                      <pre className="text-xs bg-muted p-2 rounded mt-1 overflow-auto">
                        {JSON.stringify(incident.errorDetails, null, 2)}
                      </pre>
                    </div>
                  )}

                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>Failure count: {incident.failureCount}</span>
                    <span>
                      Last failed: {new Date(incident.lastFailedAt).toLocaleString()}
                    </span>
                  </div>

                  {incident.aiDiagnosis && (
                    <Alert>
                      <Zap className="w-4 h-4" />
                      <AlertDescription>
                        <strong>AI Diagnosis:</strong> {incident.aiDiagnosis}
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <p className="text-lg font-medium">No open incidents</p>
                <p className="text-sm text-muted-foreground">All APIs are healthy</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Pending Fixes Tab */}
        <TabsContent value="fixes" className="space-y-6">
          {fixes && fixes.length > 0 ? (
            fixes.map((fix: any) => (
              <Card key={fix.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Code className="w-5 h-5" />
                        {fix.apiType} - {fix.fixType}
                      </CardTitle>
                      <CardDescription>
                        Generated: {new Date(fix.createdAt).toLocaleString()}
                      </CardDescription>
                    </div>
                    <Badge>Pending Approval</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="font-medium">AI Diagnosis:</p>
                    <p className="text-sm text-muted-foreground">{fix.diagnosis}</p>
                  </div>

                  <div>
                    <p className="font-medium">Fix Description:</p>
                    <p className="text-sm text-muted-foreground">{fix.fixDescription}</p>
                  </div>

                  <div>
                    <p className="font-medium">Generated Code:</p>
                    <pre className="text-xs bg-muted p-4 rounded mt-2 overflow-auto max-h-64">
                      {fix.fixCode}
                    </pre>
                  </div>

                  {fix.testResult && (
                    <Alert>
                      <CheckCircle className="w-4 h-4" />
                      <AlertDescription>
                        <strong>Test Result:</strong> Fix tested successfully in sandbox
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="flex gap-2">
                    <Button
                      onClick={() => approveFix.mutate({ fixId: fix.id })}
                      disabled={approveFix.isPending}
                    >
                      {approveFix.isPending && (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      )}
                      Approve & Apply Fix
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => rejectFix.mutate({ fixId: fix.id })}
                      disabled={rejectFix.isPending}
                    >
                      Reject
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="py-8 text-center">
                <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-lg font-medium">No pending fixes</p>
                <p className="text-sm text-muted-foreground">
                  AI will generate fixes when issues are detected
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Total Health Checks</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">{analytics?.totalChecks || 0}</p>
                <p className="text-xs text-muted-foreground">Last 7 days</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Incidents Resolved</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-green-500">
                  {analytics?.incidentsResolved || 0}
                </p>
                <p className="text-xs text-muted-foreground">By AI agent</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Average Response Time</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">{analytics?.avgResponseTime || 0}ms</p>
                <p className="text-xs text-muted-foreground">Across all APIs</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>API Uptime (Last 7 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              {analytics?.uptime?.map((api: any) => (
                <div key={api.type} className="flex items-center justify-between py-2 border-b last:border-0">
                  <span className="font-medium">{api.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold">{api.uptime}%</span>
                    {api.uptime >= 99 ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-yellow-500" />
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

# TitanFleet API Documentation

**Version:** 1.0.0  
**Base URL:** `https://api.titanfleet.co.uk/api/v1`  
**Authentication:** API Key (Bearer token)

---

## Table of Contents

1. [Authentication](#authentication)
2. [Rate Limiting](#rate-limiting)
3. [Error Handling](#error-handling)
4. [Webhooks](#webhooks)
5. [Endpoints](#endpoints)
   - [Vehicles](#vehicles)
   - [Deliveries](#deliveries)
   - [Drivers](#drivers)
   - [Maintenance](#maintenance)
   - [Reports](#reports)

---

## Authentication

All API requests require an API key passed in the `Authorization` header:

```http
Authorization: Bearer tf_live_abc123...
```

### Getting an API Key

1. Log in to your TitanFleet dashboard
2. Navigate to **Settings → API Keys**
3. Click **Create API Key**
4. Name your key and select scopes
5. Copy the key (it will only be shown once)

### API Key Types

- **Live keys** (`tf_live_...`): For production use
- **Test keys** (`tf_test_...`): For development/testing

### API Scopes

| Scope | Description |
|-------|-------------|
| `vehicles:read` | Read vehicle data |
| `vehicles:write` | Create/update/delete vehicles |
| `deliveries:read` | Read delivery data |
| `deliveries:write` | Create/update/delete deliveries |
| `pod:read` | Read proof of delivery |
| `pod:write` | Submit proof of delivery |
| `gps:read` | Read GPS location data |
| `maintenance:read` | Read maintenance records |
| `maintenance:write` | Create/update maintenance records |
| `reports:read` | Generate reports |
| `webhooks:read` | Read webhook configurations |
| `webhooks:write` | Create/update/delete webhooks |
| `*` | Full access (all scopes) |

---

## Rate Limiting

### Limits

- **Standard plan:** 1,000 requests per hour per API key
- **Enterprise plan:** Unlimited requests

### Headers

Rate limit information is included in response headers:

```http
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 847
X-RateLimit-Reset: 1640995200
```

### Exceeded Rate Limit

```json
{
  "error": "Rate Limit Exceeded",
  "message": "You have exceeded the rate limit of 1000 requests per hour",
  "retryAfter": 3600
}
```

---

## Error Handling

### HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request (validation error) |
| 401 | Unauthorized (invalid API key) |
| 403 | Forbidden (insufficient scope) |
| 404 | Not Found |
| 429 | Rate Limit Exceeded |
| 500 | Internal Server Error |

### Error Response Format

```json
{
  "error": "Validation Error",
  "message": "Invalid request data",
  "details": [
    {
      "field": "registration",
      "message": "Required field missing"
    }
  ]
}
```

---

## Webhooks

Webhooks allow you to receive real-time notifications when events occur in your TitanFleet account.

### Creating a Webhook

```http
POST /api/v1/webhooks
Authorization: Bearer tf_live_abc123...
Content-Type: application/json

{
  "url": "https://your-app.com/webhooks/titanfleet",
  "events": ["delivery.completed", "vehicle.speeding"]
}
```

### Webhook Events

| Event | Description |
|-------|-------------|
| `delivery.created` | New delivery created |
| `delivery.in_transit` | Delivery status changed to in transit |
| `delivery.completed` | Delivery completed (POD submitted) |
| `delivery.cancelled` | Delivery cancelled |
| `vehicle.speeding` | Vehicle exceeded speed limit |
| `vehicle.idle` | Vehicle idling for extended period |
| `maintenance.due` | Maintenance due within 7 days |
| `defect.reported` | Driver reported vehicle defect |
| `*` | All events |

### Webhook Payload

```json
{
  "id": "wh_abc123",
  "event": "delivery.completed",
  "timestamp": "2026-02-15T10:30:00Z",
  "data": {
    "delivery": {
      "id": "del_xyz789",
      "status": "completed",
      "customerName": "ACME Corp",
      ...
    },
    "pod": {
      "id": "pod_123",
      "recipientName": "John Smith",
      "gpsLat": 53.5231,
      "gpsLng": -1.1334,
      ...
    }
  }
}
```

### Webhook Signature Verification

Verify webhook authenticity using the `X-TitanFleet-Signature` header:

```javascript
const crypto = require('crypto');

function verifyWebhook(payload, signature, secret) {
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(payload))
    .digest('hex');
  
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}
```

---

## Endpoints

### Vehicles

#### List Vehicles

```http
GET /api/v1/vehicles
Authorization: Bearer tf_live_abc123...
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | string | Filter by status (`active`, `maintenance`, `retired`) |
| `limit` | integer | Number of results (default: 100, max: 1000) |
| `offset` | integer | Pagination offset (default: 0) |

**Response:**

```json
{
  "data": [
    {
      "id": "veh_abc123",
      "registration": "AB12 CDE",
      "make": "Scania",
      "model": "R450",
      "year": 2022,
      "vin": "YS2R4X20005399999",
      "fuelType": "diesel",
      "currentMileage": 125000,
      "status": "active",
      "lastLocationLat": 53.5231,
      "lastLocationLng": -1.1334,
      "lastLocationUpdatedAt": "2026-02-15T10:30:00Z",
      "createdAt": "2025-01-01T00:00:00Z",
      "updatedAt": "2026-02-15T10:30:00Z"
    }
  ],
  "pagination": {
    "limit": 100,
    "offset": 0,
    "total": 1
  }
}
```

#### Get Vehicle

```http
GET /api/v1/vehicles/{id}
Authorization: Bearer tf_live_abc123...
```

**Response:**

```json
{
  "data": {
    "id": "veh_abc123",
    "registration": "AB12 CDE",
    ...
  }
}
```

#### Get Vehicle Location

```http
GET /api/v1/vehicles/{id}/location
Authorization: Bearer tf_live_abc123...
```

**Response:**

```json
{
  "data": {
    "vehicleId": "veh_abc123",
    "registration": "AB12 CDE",
    "location": {
      "lat": 53.5231,
      "lng": -1.1334,
      "speed": 56,
      "heading": 180,
      "altitude": 100,
      "accuracy": 10,
      "recordedAt": "2026-02-15T10:30:00Z"
    }
  }
}
```

#### Create Vehicle

```http
POST /api/v1/vehicles
Authorization: Bearer tf_live_abc123...
Content-Type: application/json

{
  "registration": "AB12 CDE",
  "make": "Scania",
  "model": "R450",
  "year": 2022,
  "vin": "YS2R4X20005399999",
  "fuelType": "diesel",
  "currentMileage": 125000,
  "gpsDeviceId": "GPS123456"
}
```

**Response:**

```json
{
  "data": {
    "id": "veh_abc123",
    "registration": "AB12 CDE",
    ...
  },
  "message": "Vehicle created successfully"
}
```

#### Update Vehicle

```http
PUT /api/v1/vehicles/{id}
Authorization: Bearer tf_live_abc123...
Content-Type: application/json

{
  "currentMileage": 130000,
  "status": "maintenance"
}
```

#### Delete Vehicle

```http
DELETE /api/v1/vehicles/{id}
Authorization: Bearer tf_live_abc123...
```

**Response:**

```json
{
  "message": "Vehicle deleted successfully"
}
```

---

### Deliveries

#### List Deliveries

```http
GET /api/v1/deliveries
Authorization: Bearer tf_live_abc123...
```

**Query Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | string | Filter by status (`pending`, `in_transit`, `completed`, `cancelled`) |
| `startDate` | string | Filter by delivery date (ISO 8601) |
| `endDate` | string | Filter by delivery date (ISO 8601) |
| `limit` | integer | Number of results (default: 100) |
| `offset` | integer | Pagination offset (default: 0) |

**Response:**

```json
{
  "data": [
    {
      "id": "del_xyz789",
      "vehicleId": "veh_abc123",
      "driverId": "drv_456",
      "referenceNumber": "ORD-12345",
      "customerName": "ACME Corp",
      "pickupAddress": "123 Warehouse St, Sheffield",
      "pickupPostcode": "S1 2AB",
      "deliveryAddress": "456 Customer Rd, Leeds",
      "deliveryPostcode": "LS1 3CD",
      "deliveryScheduledAt": "2026-02-15T14:00:00Z",
      "deliveryCompletedAt": "2026-02-15T14:32:00Z",
      "status": "completed",
      "notes": "Side door delivery",
      "createdAt": "2026-02-14T10:00:00Z",
      "updatedAt": "2026-02-15T14:32:00Z"
    }
  ],
  "pagination": {
    "limit": 100,
    "offset": 0,
    "total": 1
  }
}
```

#### Get Delivery

```http
GET /api/v1/deliveries/{id}
Authorization: Bearer tf_live_abc123...
```

**Response:**

```json
{
  "data": {
    "id": "del_xyz789",
    "vehicleId": "veh_abc123",
    ...
    "pod": {
      "id": "pod_123",
      "recipientName": "John Smith",
      "gpsLat": 53.5231,
      "gpsLng": -1.1334,
      "completedAt": "2026-02-15T14:32:00Z",
      "signatureImageUrl": "https://cdn.titanfleet.co.uk/signatures/abc123.png",
      "photoUrl": "https://cdn.titanfleet.co.uk/photos/xyz789.jpg"
    }
  }
}
```

#### Get Proof of Delivery

```http
GET /api/v1/deliveries/{id}/pod
Authorization: Bearer tf_live_abc123...
```

**Response:**

```json
{
  "data": {
    "id": "pod_123",
    "deliveryId": "del_xyz789",
    "recipientName": "John Smith",
    "recipientSignature": "<svg>...</svg>",
    "gpsLat": 53.5231,
    "gpsLng": -1.1334,
    "completedAt": "2026-02-15T14:32:00Z",
    "signatureImageUrl": "https://cdn.titanfleet.co.uk/signatures/abc123.png",
    "photoUrl": "https://cdn.titanfleet.co.uk/photos/xyz789.jpg",
    "notes": "Delivered to warehouse manager"
  }
}
```

#### Create Delivery

```http
POST /api/v1/deliveries
Authorization: Bearer tf_live_abc123...
Content-Type: application/json

{
  "vehicleId": "veh_abc123",
  "driverId": "drv_456",
  "referenceNumber": "ORD-12345",
  "customerName": "ACME Corp",
  "pickupAddress": "123 Warehouse St, Sheffield",
  "pickupPostcode": "S1 2AB",
  "pickupLat": 53.3811,
  "pickupLng": -1.4701,
  "pickupScheduledAt": "2026-02-15T10:00:00Z",
  "deliveryAddress": "456 Customer Rd, Leeds",
  "deliveryPostcode": "LS1 3CD",
  "deliveryLat": 53.8008,
  "deliveryLng": -1.5491,
  "deliveryScheduledAt": "2026-02-15T14:00:00Z",
  "notes": "Side door delivery"
}
```

#### Submit Proof of Delivery

```http
POST /api/v1/deliveries/{id}/pod
Authorization: Bearer tf_live_abc123...
Content-Type: application/json

{
  "recipientName": "John Smith",
  "recipientSignature": "<svg>...</svg>",
  "gpsLat": 53.5231,
  "gpsLng": -1.1334,
  "signatureImageUrl": "https://cdn.titanfleet.co.uk/signatures/abc123.png",
  "photoUrl": "https://cdn.titanfleet.co.uk/photos/xyz789.jpg",
  "notes": "Delivered to warehouse manager"
}
```

**Response:**

```json
{
  "data": {
    "id": "pod_123",
    "deliveryId": "del_xyz789",
    ...
  },
  "message": "Proof of delivery submitted successfully"
}
```

---

## Code Examples

### JavaScript/Node.js

```javascript
const TITANFLEET_API_KEY = 'tf_live_abc123...';
const BASE_URL = 'https://api.titanfleet.co.uk/api/v1';

// List vehicles
async function listVehicles() {
  const response = await fetch(`${BASE_URL}/vehicles`, {
    headers: {
      'Authorization': `Bearer ${TITANFLEET_API_KEY}`,
      'Content-Type': 'application/json',
    },
  });
  
  const data = await response.json();
  console.log(data);
}

// Create delivery
async function createDelivery(deliveryData) {
  const response = await fetch(`${BASE_URL}/deliveries`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${TITANFLEET_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(deliveryData),
  });
  
  const data = await response.json();
  return data;
}
```

### Python

```python
import requests

TITANFLEET_API_KEY = 'tf_live_abc123...'
BASE_URL = 'https://api.titanfleet.co.uk/api/v1'

headers = {
    'Authorization': f'Bearer {TITANFLEET_API_KEY}',
    'Content-Type': 'application/json',
}

# List vehicles
response = requests.get(f'{BASE_URL}/vehicles', headers=headers)
vehicles = response.json()
print(vehicles)

# Create delivery
delivery_data = {
    'customerName': 'ACME Corp',
    'deliveryAddress': '456 Customer Rd, Leeds',
    'deliveryPostcode': 'LS1 3CD',
    'deliveryScheduledAt': '2026-02-15T14:00:00Z',
}

response = requests.post(f'{BASE_URL}/deliveries', headers=headers, json=delivery_data)
delivery = response.json()
print(delivery)
```

### PHP

```php
<?php

$apiKey = 'tf_live_abc123...';
$baseUrl = 'https://api.titanfleet.co.uk/api/v1';

// List vehicles
$ch = curl_init("$baseUrl/vehicles");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $apiKey",
    "Content-Type: application/json",
]);

$response = curl_exec($ch);
$vehicles = json_decode($response, true);
print_r($vehicles);

curl_close($ch);
?>
```

### cURL

```bash
# List vehicles
curl -X GET https://api.titanfleet.co.uk/api/v1/vehicles \
  -H "Authorization: Bearer tf_live_abc123..." \
  -H "Content-Type: application/json"

# Create delivery
curl -X POST https://api.titanfleet.co.uk/api/v1/deliveries \
  -H "Authorization: Bearer tf_live_abc123..." \
  -H "Content-Type: application/json" \
  -d '{
    "customerName": "ACME Corp",
    "deliveryAddress": "456 Customer Rd, Leeds",
    "deliveryPostcode": "LS1 3CD",
    "deliveryScheduledAt": "2026-02-15T14:00:00Z"
  }'
```

---

## Support

- **Email:** api-support@titanfleet.co.uk
- **Documentation:** https://docs.titanfleet.co.uk/api
- **Status Page:** https://status.titanfleet.co.uk

---

## Changelog

### v1.0.0 (2026-02-15)

- Initial API release
- Vehicles endpoints
- Deliveries endpoints
- POD endpoints
- Webhooks support
- Rate limiting
- API key authentication

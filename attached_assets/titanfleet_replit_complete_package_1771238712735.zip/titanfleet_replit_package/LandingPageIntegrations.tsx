/**
 * Landing Page Integrations Section
 * Showcases TitanFleet's API integrations with company logos
 */

import { ArrowRight, Check, Plug2, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function LandingPageIntegrations() {
  const integrations = [
    {
      name: 'Resend',
      logo: '/integrations/resend-logo.svg',
      description: 'Automated email notifications',
      category: 'Email',
      features: ['Delivery confirmations', 'POD notifications', 'Maintenance alerts'],
    },
    {
      name: 'Stripe',
      logo: '/integrations/stripe-logo.svg',
      description: 'Secure payment processing',
      category: 'Payments',
      features: ['Subscription billing', 'Invoice payments', 'Secure checkout'],
    },
    {
      name: 'Xero',
      logo: '/integrations/xero-logo.svg',
      description: 'Accounting automation',
      category: 'Accounting',
      features: ['Invoice sync', 'Expense tracking', 'Financial reports'],
    },
    {
      name: 'QuickBooks',
      logo: '/integrations/quickbooks-logo.svg',
      description: 'Bookkeeping integration',
      category: 'Accounting',
      features: ['Invoice creation', 'Payment tracking', 'Tax reporting'],
    },
    {
      name: 'OpenStreetMap',
      logo: '/integrations/openstreetmap-logo.svg',
      description: 'Route optimization',
      category: 'Maps',
      features: ['Geocoding', 'Route planning', 'Distance calculation'],
    },
  ];

  return (
    <section className="py-24 bg-gradient-to-b from-background to-muted/20">
      <div className="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Plug2 className="w-4 h-4" />
            Seamless Integrations
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Connect with the tools you already use
          </h2>
          
          <p className="text-xl text-muted-foreground">
            TitanFleet integrates with your favorite services to streamline your fleet operations.
            No manual data entry, no switching between apps.
          </p>
        </div>

        {/* Integration Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {integrations.map((integration) => (
            <Card key={integration.name} className="group hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                {/* Logo and Category */}
                <div className="flex items-start justify-between mb-4">
                  <div className="bg-white p-3 rounded-lg shadow-sm border">
                    <img
                      src={integration.logo}
                      alt={`${integration.name} logo`}
                      className="h-8 w-auto object-contain"
                      onError={(e) => {
                        // Fallback if logo fails to load
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.parentElement!.innerHTML = `<span class="text-lg font-bold">${integration.name}</span>`;
                      }}
                    />
                  </div>
                  <span className="text-xs font-medium bg-muted px-2 py-1 rounded">
                    {integration.category}
                  </span>
                </div>

                {/* Name and Description */}
                <h3 className="text-xl font-bold mb-2">{integration.name}</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  {integration.description}
                </p>

                {/* Features List */}
                <ul className="space-y-2">
                  {integration.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}

          {/* API Access Card */}
          <Card className="group hover:shadow-lg transition-shadow bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
            <CardContent className="p-6 h-full flex flex-col">
              <div className="bg-primary/10 p-3 rounded-lg w-fit mb-4">
                <Zap className="w-8 h-8 text-primary" />
              </div>

              <h3 className="text-xl font-bold mb-2">Full API Access</h3>
              <p className="text-muted-foreground text-sm mb-4 flex-grow">
                Build custom integrations with our comprehensive REST API. Complete documentation and code examples included.
              </p>

              <ul className="space-y-2 mb-4">
                <li className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>RESTful API endpoints</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Webhook support</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                  <span>Real-time data sync</span>
                </li>
              </ul>

              <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                View API Docs
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="text-center">
            <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-bold mb-2">Auto-Healing APIs</h3>
            <p className="text-sm text-muted-foreground">
              AI-powered monitoring automatically detects and fixes API issues before you notice
            </p>
          </div>

          <div className="text-center">
            <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-bold mb-2">Zero Downtime</h3>
            <p className="text-sm text-muted-foreground">
              Automatic failover and redundancy ensure your integrations always work
            </p>
          </div>

          <div className="text-center">
            <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
              <Plug2 className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-bold mb-2">Easy Setup</h3>
            <p className="text-sm text-muted-foreground">
              Connect your accounts in minutes with our simple configuration wizard
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button size="lg" className="gap-2">
            View All Integrations
            <ArrowRight className="w-4 h-4" />
          </Button>
          <p className="text-sm text-muted-foreground mt-4">
            Free 14-day trial • No credit card required • Setup in 5 minutes
          </p>
        </div>

        {/* Trust Bar */}
        <div className="mt-16 pt-8 border-t">
          <p className="text-center text-sm text-muted-foreground mb-6">
            Trusted by UK haulage companies to power their operations
          </p>
          <div className="flex flex-wrap items-center justify-center gap-8 opacity-60">
            {integrations.slice(0, 4).map((integration) => (
              <img
                key={integration.name}
                src={integration.logo}
                alt={`${integration.name} logo`}
                className="h-6 w-auto object-contain grayscale hover:grayscale-0 transition-all"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

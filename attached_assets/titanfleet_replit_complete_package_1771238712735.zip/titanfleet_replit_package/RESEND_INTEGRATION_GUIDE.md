# TitanFleet + Resend Email Integration Guide

Complete guide for integrating Resend email notifications into TitanFleet.

---

## 🎯 What This Does

Allows TitanFleet customers to:
1. **Connect their own Resend account** (bring your own API key)
2. **Send branded emails** from their own domain (e.g., notifications@acmehaulage.com)
3. **Automate notifications** for deliveries, maintenance, defects, etc.
4. **Control preferences** (choose which events trigger emails)

---

## 📦 What's Included

### 1. **Email Service** (`services/email.ts`)
- Send delivery completion emails (with POD, signature, photo)
- Send delivery created notifications
- Send maintenance due reminders
- Send vehicle defect alerts
- Send test emails
- Resend client management

### 2. **Database Schema** (`email_settings_schema.sql`)
- Email settings storage (API keys, from addresses, preferences)
- Email delivery logs (tracking sent emails)
- Notification preferences per user

### 3. **tRPC Procedures** (`trpc_email_procedures.ts`)
- Get/update email settings
- Update notification preferences
- Send test emails
- View email logs
- Manage Resend domains

### 4. **React UI Component** (`EmailSettings.tsx`)
- Full settings page with tabs (Setup, Preferences, Domains, Logs)
- API key management
- Email configuration
- Test email sender
- Notification toggles
- Domain verification status
- Email delivery logs

---

## 🚀 Integration Steps

### Step 1: Install Resend Package

```bash
pnpm add resend
```

### Step 2: Add Database Tables

```bash
# Run the SQL schema
mysql -u root -p your_database < email_settings_schema.sql
```

Or add to your Drizzle schema:

```typescript
// drizzle/schema.ts
export const userSettings = sqliteTable('user_settings', {
  // ... existing columns ...
  resendApiKey: text('resend_api_key'),
  emailFromAddress: text('email_from_address'),
  emailFromName: text('email_from_name'),
  emailReplyTo: text('email_reply_to'),
  notificationEmail: text('notification_email'),
  emailNotificationsEnabled: integer('email_notifications_enabled', { mode: 'boolean' }).default(true),
  notifyDeliveryCreated: integer('notify_delivery_created', { mode: 'boolean' }).default(true),
  notifyDeliveryCompleted: integer('notify_delivery_completed', { mode: 'boolean' }).default(true),
  notifyMaintenanceDue: integer('notify_maintenance_due', { mode: 'boolean' }).default(true),
  notifyDefectReported: integer('notify_defect_reported', { mode: 'boolean' }).default(true),
  notifyDriverHoursWarning: integer('notify_driver_hours_warning', { mode: 'boolean' }).default(true),
});

export const emailLogs = sqliteTable('email_logs', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  emailType: text('email_type').notNull(),
  recipient: text('recipient').notNull(),
  subject: text('subject'),
  status: text('status').notNull(), // sent, failed, bounced
  errorMessage: text('error_message'),
  resendMessageId: text('resend_message_id'),
  sentAt: integer('sent_at', { mode: 'timestamp' }).notNull().default(sql`CURRENT_TIMESTAMP`),
});
```

### Step 3: Copy Email Service

```bash
cp services/email.ts server/services/
```

### Step 4: Add tRPC Procedures

Add the email router to your `server/routers.ts`:

```typescript
import { emailRouter } from './trpc_email_procedures';

export const appRouter = router({
  // ... existing routers ...
  email: router(emailRouter),
});
```

### Step 5: Trigger Emails in Your Code

In your delivery completion handler:

```typescript
// server/routers.ts - after POD submission
import { sendDeliveryCompletedEmail } from './services/email';

// In your delivery completion mutation:
const [newPod] = await db.insert(deliveryPods).values({...}).returning();

// Send email notification
await sendDeliveryCompletedEmail(ctx.user.id, delivery, newPod);
```

### Step 6: Add Email Settings Page

```bash
cp EmailSettings.tsx client/src/pages/
```

Add route in `client/src/App.tsx`:

```typescript
import EmailSettings from './pages/EmailSettings';

// In your routes:
<Route path="/settings/email" element={<EmailSettings />} />
```

Add navigation link in your settings menu:

```typescript
<Link to="/settings/email">Email Notifications</Link>
```

---

## 🎨 UI Preview

The Email Settings page has 4 tabs:

### **1. Setup Tab**
- Connection status badge (Active/Inactive)
- Resend API key input (password field)
- Email configuration (from address, from name, reply-to)
- Notification email (where alerts are sent)
- Test email sender
- Remove API key button

### **2. Preferences Tab**
- Toggle switches for each notification type:
  - ✅ Delivery Created
  - ✅ Delivery Completed
  - ✅ Maintenance Due
  - ✅ Defect Reported
  - ✅ Driver Hours Warning

### **3. Domains Tab**
- List of verified domains from Resend
- Domain status badges (verified/pending)
- Link to Resend dashboard to add domains

### **4. Logs Tab**
- Recent email delivery history
- Subject, recipient, timestamp
- Status badges (sent/failed)
- Error messages for failed emails

---

## 📧 Email Templates

### Delivery Completed Email

**Subject:** ✅ Delivery Completed - [Reference Number]

**Includes:**
- Reference number
- Delivery address
- Completion time
- Recipient name
- Notes (if any)
- Signature image
- POD photo
- GPS location (Google Maps link)

**Design:**
- Blue header with checkmark icon
- Clean card layout
- Responsive (mobile-friendly)
- Professional styling

### Delivery Created Email

**Subject:** 📦 Delivery Scheduled - [Reference Number]

**Includes:**
- Reference number
- Scheduled delivery time
- Delivery address
- Notes

### Maintenance Due Email

**Subject:** ⚠️ Maintenance Due - [Vehicle Registration]

**Includes:**
- Vehicle registration
- Make/model
- Maintenance type
- Due date
- Due mileage
- Warning for dangerous defects

### Defect Alert Email

**Subject:** 🚨 [SEVERITY] Defect Reported - [Vehicle Registration]

**Includes:**
- Severity badge (color-coded)
- Vehicle registration
- Defect category
- Reporter name
- Description
- Photo (if available)
- Warning banner for dangerous defects

---

## 🔧 Customization

### Add More Email Types

Create new functions in `services/email.ts`:

```typescript
export async function sendDriverHoursWarningEmail(
  userId: string,
  driver: any,
  hoursData: any
): Promise<boolean> {
  const resend = await getResendClient(userId);
  if (!resend) return false;

  const settings = await getEmailSettings(userId);

  await resend.emails.send({
    from: `${settings.fromName} <${settings.fromAddress}>`,
    to: settings.notificationEmail,
    subject: `⚠️ Driver Hours Warning - ${driver.firstName} ${driver.lastName}`,
    html: `...your HTML template...`,
  });

  return true;
}
```

### Customize Email Templates

Edit the HTML in `services/email.ts`:

```typescript
html: `
  <!DOCTYPE html>
  <html>
  <head>
    <style>
      /* Your custom styles */
      .header { background: #YOUR_BRAND_COLOR; }
    </style>
  </head>
  <body>
    <!-- Your custom template -->
  </body>
  </html>
`
```

### Add Email Attachments

```typescript
await resend.emails.send({
  from: `${settings.fromName} <${settings.fromAddress}>`,
  to: delivery.customerEmail,
  subject: 'Delivery Completed',
  html: '...',
  attachments: [
    {
      filename: 'pod.pdf',
      content: pdfBuffer, // Buffer or base64 string
    },
  ],
});
```

---

## 🔒 Security Best Practices

### 1. **Never Log API Keys**

```typescript
// ❌ Bad
console.log('Resend API key:', settings.resendApiKey);

// ✅ Good
console.log('Resend API key configured:', !!settings.resendApiKey);
```

### 2. **Validate API Keys**

```typescript
// In updateSettings mutation
if (input.resendApiKey) {
  try {
    const resend = new Resend(input.resendApiKey);
    await resend.domains.list(); // Test the key
  } catch (error) {
    throw new Error('Invalid Resend API key');
  }
}
```

### 3. **Rate Limit Email Sending**

```typescript
// Prevent abuse - limit emails per user per hour
const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
const [emailCount] = await db
  .select({ count: sql<number>`count(*)` })
  .from(emailLogs)
  .where(
    and(
      eq(emailLogs.userId, userId),
      gte(emailLogs.sentAt, oneHourAgo)
    )
  );

if (emailCount.count > 100) {
  throw new Error('Email rate limit exceeded');
}
```

### 4. **Sanitize Email Content**

```typescript
import DOMPurify from 'isomorphic-dompurify';

const sanitizedNotes = DOMPurify.sanitize(delivery.notes);
```

---

## 📊 Monitoring & Analytics

### Track Email Delivery Success Rate

```sql
SELECT 
  email_type,
  COUNT(*) as total,
  SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as successful,
  ROUND(SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as success_rate
FROM email_logs
WHERE sent_at >= NOW() - INTERVAL 7 DAY
GROUP BY email_type;
```

### Most Common Email Failures

```sql
SELECT 
  error_message,
  COUNT(*) as occurrences
FROM email_logs
WHERE status = 'failed'
  AND sent_at >= NOW() - INTERVAL 7 DAY
GROUP BY error_message
ORDER BY occurrences DESC
LIMIT 10;
```

### Emails Sent Per User

```sql
SELECT 
  u.name,
  COUNT(el.id) as emails_sent
FROM users u
LEFT JOIN email_logs el ON u.id = el.user_id
WHERE el.sent_at >= NOW() - INTERVAL 30 DAY
GROUP BY u.id
ORDER BY emails_sent DESC;
```

---

## 🧪 Testing

### Test Email Configuration

```typescript
// In your test file
import { sendTestEmail } from './services/email';

test('should send test email', async () => {
  const result = await sendTestEmail(userId, 'test@example.com');
  expect(result).toBe(true);
});
```

### Test Email Delivery

```bash
# Via UI: Go to Email Settings → Setup → Send Test Email

# Via API:
curl -X POST http://localhost:3000/api/trpc/email.sendTestEmail \
  -H "Authorization: Bearer YOUR_SESSION_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"toEmail": "test@example.com"}'
```

---

## 💰 Pricing Considerations

### Resend Pricing (as of 2026)

- **Free tier:** 100 emails/day, 3,000 emails/month
- **Pro tier:** $20/month for 50,000 emails/month
- **Scale tier:** Custom pricing for higher volumes

### TitanFleet Pricing Strategy

**Option 1: Free (Included)**
- Include Resend integration in £59/month plan
- Customers bring their own Resend API key
- No additional cost to you or customer

**Option 2: Premium Add-On**
- Standard plan: £59/month (no email notifications)
- Email add-on: +£10/month (includes 1,000 emails/month via your Resend account)
- Enterprise plan: £99/month (unlimited emails)

**Recommendation:** **Free (Option 1)** - Let customers use their own Resend accounts. This:
- ✅ No infrastructure cost for you
- ✅ Customers control their own email sending
- ✅ Customers can use their own domains
- ✅ Competitive advantage (most competitors charge for email notifications)

---

## 🎯 Marketing Angle

### Website Copy

**Features Page:**
> **Email Notifications with Resend**
> 
> Automatically send branded delivery notifications, POD confirmations, and maintenance alerts to your customers. Connect your Resend account and send emails from your own domain—no additional fees.

**Pricing Page:**
> ✅ Email notifications (bring your own Resend account)  
> ✅ Unlimited email templates  
> ✅ Delivery completion emails with POD  
> ✅ Maintenance reminders  
> ✅ Defect alerts

### Competitor Comparison

| Feature | TitanFleet | Teletrac Navman | Verizon Connect |
|---------|-----------|-----------------|-----------------|
| Email notifications | ✅ Free (BYOR) | ❌ £10/month | ❌ £15/month |
| Custom domain | ✅ Yes | ✅ Yes | ✅ Yes |
| Email templates | ✅ 5+ built-in | ✅ 3 built-in | ✅ 2 built-in |
| Email logs | ✅ Yes | ❌ No | ✅ Yes |

**BYOR = Bring Your Own Resend**

---

## 🚢 Deployment Checklist

- [ ] Install `resend` package
- [ ] Add database tables/columns
- [ ] Copy email service file
- [ ] Add tRPC procedures
- [ ] Add email settings page
- [ ] Add navigation link
- [ ] Test email sending
- [ ] Update documentation
- [ ] Add to onboarding flow
- [ ] Promote in marketing materials

---

## 📚 Resources

- **Resend Documentation:** https://resend.com/docs
- **Resend API Keys:** https://resend.com/api-keys
- **Resend Domains:** https://resend.com/domains
- **Resend React Email:** https://react.email (for advanced templates)

---

## ✅ What's Already Done

✅ **Email service** - Complete with 4 email types  
✅ **Database schema** - Settings, logs, preferences  
✅ **tRPC procedures** - Full CRUD for email settings  
✅ **React UI** - Complete settings page with 4 tabs  
✅ **Email templates** - Professional HTML designs  
✅ **Error handling** - Validation, logging, retries  
✅ **Security** - API key validation, sanitization  

---

## 🎯 Next Steps

1. **Copy files** to your project
2. **Run database migrations**
3. **Add email router** to tRPC
4. **Add settings page** to UI
5. **Test with Resend account**
6. **Deploy** and promote!

**Estimated integration time:** 1-2 hours

All the complex logic (Resend client management, email templates, error handling, logging) is already implemented. You just need to wire it into your existing TitanFleet codebase!

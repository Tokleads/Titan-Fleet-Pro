/**
 * Agentic API Health Monitor (Updated for OpenStreetMap)
 * Automatically detects and fixes broken API integrations
 */

import { db } from '../db';
import { apiHealthChecks, apiHealthIncidents, apiHealthFixes } from '../schema';
import { eq, desc, and, gte } from 'drizzle-orm';
import { invokeLLM } from '../_core/llm';
import { Resend } from 'resend';

// API integrations to monitor
export const MONITORED_APIS = {
  RESEND: 'resend',
  NOMINATIM: 'nominatim', // OpenStreetMap geocoding
  OSRM: 'osrm', // OpenStreetMap routing
  STRIPE: 'stripe',
  XERO: 'xero',
  QUICKBOOKS: 'quickbooks',
} as const;

type ApiType = typeof MONITORED_APIS[keyof typeof MONITORED_APIS];

/**
 * Health check result
 */
interface HealthCheckResult {
  apiType: ApiType;
  status: 'healthy' | 'degraded' | 'down';
  responseTime: number;
  errorMessage?: string;
  errorDetails?: any;
  checkedAt: Date;
}

/**
 * Run health checks on all APIs
 * Called by cron job every hour
 */
export async function runAllHealthChecks(): Promise<void> {
  console.log('[API Health Monitor] Starting health checks...');

  const results: HealthCheckResult[] = [];

  // Check each API
  for (const apiType of Object.values(MONITORED_APIS)) {
    try {
      const result = await checkApiHealth(apiType);
      results.push(result);

      // Log to database
      await db.insert(apiHealthChecks).values({
        id: crypto.randomUUID(),
        apiType,
        status: result.status,
        responseTime: result.responseTime,
        errorMessage: result.errorMessage || null,
        errorDetails: result.errorDetails || null,
        checkedAt: result.checkedAt,
      });

      // If unhealthy, create incident and trigger AI agent
      if (result.status !== 'healthy') {
        await handleApiFailure(result);
      }
    } catch (error) {
      console.error(`[API Health Monitor] Error checking ${apiType}:`, error);
    }
  }

  console.log('[API Health Monitor] Health checks completed:', {
    total: results.length,
    healthy: results.filter((r) => r.status === 'healthy').length,
    degraded: results.filter((r) => r.status === 'degraded').length,
    down: results.filter((r) => r.status === 'down').length,
  });
}

/**
 * Check health of a specific API
 */
async function checkApiHealth(apiType: ApiType): Promise<HealthCheckResult> {
  const startTime = Date.now();

  try {
    switch (apiType) {
      case MONITORED_APIS.RESEND:
        return await checkResendHealth(startTime);
      case MONITORED_APIS.NOMINATIM:
        return await checkNominatimHealth(startTime);
      case MONITORED_APIS.OSRM:
        return await checkOSRMHealth(startTime);
      case MONITORED_APIS.STRIPE:
        return await checkStripeHealth(startTime);
      case MONITORED_APIS.XERO:
        return await checkXeroHealth(startTime);
      case MONITORED_APIS.QUICKBOOKS:
        return await checkQuickBooksHealth(startTime);
      default:
        throw new Error(`Unknown API type: ${apiType}`);
    }
  } catch (error) {
    const responseTime = Date.now() - startTime;
    return {
      apiType,
      status: 'down',
      responseTime,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
      errorDetails: error,
      checkedAt: new Date(),
    };
  }
}

/**
 * Check Resend email API health
 */
async function checkResendHealth(startTime: number): Promise<HealthCheckResult> {
  try {
    const resend = new Resend(process.env.RESEND_API_KEY);

    // Try to fetch API keys list (lightweight check)
    const response = await fetch('https://api.resend.com/api-keys', {
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      },
      signal: AbortSignal.timeout(10000),
    });

    const responseTime = Date.now() - startTime;

    if (response.ok) {
      return {
        apiType: MONITORED_APIS.RESEND,
        status: 'healthy',
        responseTime,
        checkedAt: new Date(),
      };
    } else {
      const errorData = await response.json();
      return {
        apiType: MONITORED_APIS.RESEND,
        status: 'down',
        responseTime,
        errorMessage: `HTTP ${response.status}: ${errorData.message || 'Unknown error'}`,
        errorDetails: errorData,
        checkedAt: new Date(),
      };
    }
  } catch (error) {
    const responseTime = Date.now() - startTime;
    return {
      apiType: MONITORED_APIS.RESEND,
      status: 'down',
      responseTime,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
      errorDetails: error,
      checkedAt: new Date(),
    };
  }
}

/**
 * Check OpenStreetMap Nominatim (geocoding) health
 */
async function checkNominatimHealth(startTime: number): Promise<HealthCheckResult> {
  try {
    // Test geocoding with a known address
    const response = await fetch(
      'https://nominatim.openstreetmap.org/search?format=json&q=London,UK&limit=1',
      {
        headers: {
          'User-Agent': 'TitanFleet/1.0', // Required by Nominatim
        },
        signal: AbortSignal.timeout(10000),
      }
    );

    const responseTime = Date.now() - startTime;

    if (response.ok) {
      const data = await response.json();
      
      // Check if we got valid results
      if (Array.isArray(data) && data.length > 0 && data[0].lat && data[0].lon) {
        return {
          apiType: MONITORED_APIS.NOMINATIM,
          status: 'healthy',
          responseTime,
          checkedAt: new Date(),
        };
      } else {
        return {
          apiType: MONITORED_APIS.NOMINATIM,
          status: 'degraded',
          responseTime,
          errorMessage: 'Nominatim returned no results for test query',
          errorDetails: data,
          checkedAt: new Date(),
        };
      }
    } else {
      return {
        apiType: MONITORED_APIS.NOMINATIM,
        status: 'down',
        responseTime,
        errorMessage: `HTTP ${response.status}: ${response.statusText}`,
        checkedAt: new Date(),
      };
    }
  } catch (error) {
    const responseTime = Date.now() - startTime;
    return {
      apiType: MONITORED_APIS.NOMINATIM,
      status: 'down',
      responseTime,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
      errorDetails: error,
      checkedAt: new Date(),
    };
  }
}

/**
 * Check OpenStreetMap OSRM (routing) health
 */
async function checkOSRMHealth(startTime: number): Promise<HealthCheckResult> {
  try {
    // Test routing between two points in London
    // Start: Big Ben (-0.1276, 51.5074)
    // End: Tower Bridge (-0.0899, 51.5155)
    const response = await fetch(
      'https://router.project-osrm.org/route/v1/driving/-0.1276,51.5074;-0.0899,51.5155?overview=false',
      {
        signal: AbortSignal.timeout(10000),
      }
    );

    const responseTime = Date.now() - startTime;

    if (response.ok) {
      const data = await response.json();
      
      // Check if we got valid route
      if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
        return {
          apiType: MONITORED_APIS.OSRM,
          status: 'healthy',
          responseTime,
          checkedAt: new Date(),
        };
      } else {
        return {
          apiType: MONITORED_APIS.OSRM,
          status: 'degraded',
          responseTime,
          errorMessage: `OSRM returned code: ${data.code}`,
          errorDetails: data,
          checkedAt: new Date(),
        };
      }
    } else {
      return {
        apiType: MONITORED_APIS.OSRM,
        status: 'down',
        responseTime,
        errorMessage: `HTTP ${response.status}: ${response.statusText}`,
        checkedAt: new Date(),
      };
    }
  } catch (error) {
    const responseTime = Date.now() - startTime;
    return {
      apiType: MONITORED_APIS.OSRM,
      status: 'down',
      responseTime,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
      errorDetails: error,
      checkedAt: new Date(),
    };
  }
}

/**
 * Check Stripe API health
 */
async function checkStripeHealth(startTime: number): Promise<HealthCheckResult> {
  try {
    // Simple balance check (lightweight)
    const response = await fetch('https://api.stripe.com/v1/balance', {
      headers: {
        Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
      },
      signal: AbortSignal.timeout(10000),
    });

    const responseTime = Date.now() - startTime;

    if (response.ok) {
      return {
        apiType: MONITORED_APIS.STRIPE,
        status: 'healthy',
        responseTime,
        checkedAt: new Date(),
      };
    } else {
      const errorData = await response.json();
      return {
        apiType: MONITORED_APIS.STRIPE,
        status: 'down',
        responseTime,
        errorMessage: `HTTP ${response.status}: ${errorData.error?.message || 'Unknown error'}`,
        errorDetails: errorData,
        checkedAt: new Date(),
      };
    }
  } catch (error) {
    const responseTime = Date.now() - startTime;
    return {
      apiType: MONITORED_APIS.STRIPE,
      status: 'down',
      responseTime,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
      errorDetails: error,
      checkedAt: new Date(),
    };
  }
}

/**
 * Check Xero API health (placeholder)
 */
async function checkXeroHealth(startTime: number): Promise<HealthCheckResult> {
  // TODO: Implement Xero health check when integration is added
  const responseTime = Date.now() - startTime;
  return {
    apiType: MONITORED_APIS.XERO,
    status: 'healthy',
    responseTime,
    checkedAt: new Date(),
  };
}

/**
 * Check QuickBooks API health (placeholder)
 */
async function checkQuickBooksHealth(startTime: number): Promise<HealthCheckResult> {
  // TODO: Implement QuickBooks health check when integration is added
  const responseTime = Date.now() - startTime;
  return {
    apiType: MONITORED_APIS.QUICKBOOKS,
    status: 'healthy',
    responseTime,
    checkedAt: new Date(),
  };
}

/**
 * Handle API failure - create incident and trigger AI agent
 */
async function handleApiFailure(result: HealthCheckResult): Promise<void> {
  console.log(`[API Health Monitor] API failure detected: ${result.apiType}`);

  // Check if there's already an open incident for this API
  const [existingIncident] = await db
    .select()
    .from(apiHealthIncidents)
    .where(
      and(
        eq(apiHealthIncidents.apiType, result.apiType),
        eq(apiHealthIncidents.status, 'open')
      )
    )
    .limit(1);

  if (existingIncident) {
    // Update existing incident
    await db
      .update(apiHealthIncidents)
      .set({
        failureCount: existingIncident.failureCount + 1,
        lastFailedAt: new Date(),
        errorMessage: result.errorMessage || existingIncident.errorMessage,
        errorDetails: result.errorDetails || existingIncident.errorDetails,
      })
      .where(eq(apiHealthIncidents.id, existingIncident.id));

    console.log(`[API Health Monitor] Updated existing incident ${existingIncident.id}`);
  } else {
    // Create new incident
    const incidentId = crypto.randomUUID();
    await db.insert(apiHealthIncidents).values({
      id: incidentId,
      apiType: result.apiType,
      status: 'open',
      severity: result.status === 'down' ? 'critical' : 'warning',
      errorMessage: result.errorMessage || 'Unknown error',
      errorDetails: result.errorDetails || null,
      failureCount: 1,
      detectedAt: new Date(),
      lastFailedAt: new Date(),
    });

    console.log(`[API Health Monitor] Created new incident ${incidentId}`);

    // Trigger AI agent to diagnose and fix
    await triggerAiAgent(incidentId, result);
  }
}

/**
 * Trigger AI agent to diagnose and generate fix
 */
async function triggerAiAgent(incidentId: string, result: HealthCheckResult): Promise<void> {
  console.log(`[AI Agent] Analyzing incident ${incidentId}...`);

  try {
    // Step 1: Fetch latest API documentation
    const apiDocs = await fetchApiDocumentation(result.apiType);

    // Step 2: AI diagnoses the issue
    const diagnosis = await diagnoseApiError(result, apiDocs);

    // Step 3: AI generates a fix
    const fix = await generateApiFix(incidentId, result, diagnosis, apiDocs);

    // Step 4: Test the fix in sandbox
    const testResult = await testApiFix(result.apiType, fix);

    // Step 5: Store fix for admin approval
    await db.insert(apiHealthFixes).values({
      id: crypto.randomUUID(),
      incidentId,
      apiType: result.apiType,
      diagnosis: diagnosis.summary,
      fixDescription: fix.description,
      fixCode: fix.code,
      fixType: fix.type,
      status: 'pending_approval',
      testedAt: new Date(),
      testResult: testResult,
    });

    console.log(`[AI Agent] Fix generated and awaiting approval for incident ${incidentId}`);
  } catch (error) {
    console.error(`[AI Agent] Error processing incident ${incidentId}:`, error);
  }
}

/**
 * Fetch latest API documentation
 */
async function fetchApiDocumentation(apiType: ApiType): Promise<string> {
  const docUrls: Record<ApiType, string> = {
    resend: 'https://resend.com/docs/api-reference/introduction',
    nominatim: 'https://nominatim.org/release-docs/latest/api/Search/',
    osrm: 'http://project-osrm.org/docs/v5.24.0/api/',
    stripe: 'https://stripe.com/docs/api',
    xero: 'https://developer.xero.com/documentation/api/api-overview',
    quickbooks: 'https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities/account',
  };

  const url = docUrls[apiType];
  
  try {
    const response = await fetch(url);
    const html = await response.text();
    
    // Extract text content (simplified - in production, use proper HTML parsing)
    const textContent = html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    
    // Limit to first 10,000 characters to avoid token limits
    return textContent.substring(0, 10000);
  } catch (error) {
    console.error(`[AI Agent] Error fetching docs for ${apiType}:`, error);
    return `Documentation unavailable for ${apiType}`;
  }
}

/**
 * AI diagnoses the API error
 */
async function diagnoseApiError(
  result: HealthCheckResult,
  apiDocs: string
): Promise<{ summary: string; rootCause: string; recommendedActions: string[] }> {
  const prompt = `You are an expert API integration engineer. An API health check has failed.

API: ${result.apiType}
Status: ${result.status}
Error Message: ${result.errorMessage}
Error Details: ${JSON.stringify(result.errorDetails, null, 2)}
Response Time: ${result.responseTime}ms

Latest API Documentation (excerpt):
${apiDocs}

Please analyze this failure and provide:
1. A brief summary of what went wrong
2. The root cause
3. Recommended actions to fix it

Respond in JSON format:
{
  "summary": "Brief description of the issue",
  "rootCause": "Technical explanation of why it failed",
  "recommendedActions": ["Action 1", "Action 2", "Action 3"]
}`;

  const response = await invokeLLM({
    messages: [
      { role: 'system', content: 'You are an expert API integration engineer.' },
      { role: 'user', content: prompt },
    ],
    response_format: {
      type: 'json_schema',
      json_schema: {
        name: 'api_diagnosis',
        strict: true,
        schema: {
          type: 'object',
          properties: {
            summary: { type: 'string' },
            rootCause: { type: 'string' },
            recommendedActions: {
              type: 'array',
              items: { type: 'string' },
            },
          },
          required: ['summary', 'rootCause', 'recommendedActions'],
          additionalProperties: false,
        },
      },
    },
  });

  const diagnosis = JSON.parse(response.choices[0].message.content);
  console.log('[AI Agent] Diagnosis:', diagnosis);
  
  return diagnosis;
}

/**
 * AI generates a fix for the API issue
 */
async function generateApiFix(
  incidentId: string,
  result: HealthCheckResult,
  diagnosis: any,
  apiDocs: string
): Promise<{ description: string; code: string; type: string }> {
  const prompt = `You are an expert API integration engineer. Generate a code fix for this API failure.

API: ${result.apiType}
Diagnosis: ${diagnosis.summary}
Root Cause: ${diagnosis.rootCause}
Recommended Actions: ${diagnosis.recommendedActions.join(', ')}

Latest API Documentation (excerpt):
${apiDocs}

Generate TypeScript code to fix this issue. The fix should be production-ready and include:
1. Clear description of what the fix does
2. The actual TypeScript code
3. Fix type (code_patch, config_update, or api_key_refresh)

Respond in JSON format:
{
  "description": "What this fix does",
  "code": "// TypeScript code here",
  "type": "code_patch"
}`;

  const response = await invokeLLM({
    messages: [
      { role: 'system', content: 'You are an expert TypeScript developer.' },
      { role: 'user', content: prompt },
    ],
    response_format: {
      type: 'json_schema',
      json_schema: {
        name: 'api_fix',
        strict: true,
        schema: {
          type: 'object',
          properties: {
            description: { type: 'string' },
            code: { type: 'string' },
            type: { type: 'string', enum: ['code_patch', 'config_update', 'api_key_refresh'] },
          },
          required: ['description', 'code', 'type'],
          additionalProperties: false,
        },
      },
    },
  });

  const fix = JSON.parse(response.choices[0].message.content);
  console.log('[AI Agent] Generated fix:', fix.description);
  
  return fix;
}

/**
 * Test the AI-generated fix in a sandbox
 */
async function testApiFix(apiType: ApiType, fix: any): Promise<any> {
  console.log(`[AI Agent] Testing fix for ${apiType} in sandbox...`);

  // TODO: Implement actual sandbox testing
  // For now, return a mock success result
  return {
    success: true,
    message: 'Fix tested successfully in sandbox',
    testedAt: new Date().toISOString(),
  };
}

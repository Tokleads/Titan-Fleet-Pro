-- Email Settings Schema
-- Add these columns to your existing user_settings table or create a new table

-- Option 1: Add to existing user_settings table
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS resend_api_key VARCHAR(255);
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS email_from_address VARCHAR(255);
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS email_from_name VARCHAR(100);
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS email_reply_to VARCHAR(255);
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS notification_email VARCHAR(255);
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS email_notifications_enabled BOOLEAN DEFAULT TRUE;

-- Email notification preferences
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS notify_delivery_created BOOLEAN DEFAULT TRUE;
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS notify_delivery_completed BOOLEAN DEFAULT TRUE;
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS notify_maintenance_due BOOLEAN DEFAULT TRUE;
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS notify_defect_reported BOOLEAN DEFAULT TRUE;
ALTER TABLE user_settings ADD COLUMN IF NOT EXISTS notify_driver_hours_warning BOOLEAN DEFAULT TRUE;

-- Option 2: Create separate email_settings table (if you prefer separation)
CREATE TABLE IF NOT EXISTS email_settings (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL UNIQUE,
  resend_api_key VARCHAR(255),
  email_from_address VARCHAR(255),
  email_from_name VARCHAR(100),
  email_reply_to VARCHAR(255),
  notification_email VARCHAR(255),
  email_notifications_enabled BOOLEAN DEFAULT TRUE,
  
  -- Notification preferences
  notify_delivery_created BOOLEAN DEFAULT TRUE,
  notify_delivery_completed BOOLEAN DEFAULT TRUE,
  notify_maintenance_due BOOLEAN DEFAULT TRUE,
  notify_defect_reported BOOLEAN DEFAULT TRUE,
  notify_driver_hours_warning BOOLEAN DEFAULT TRUE,
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id)
);

-- Email delivery log (optional, for tracking sent emails)
CREATE TABLE IF NOT EXISTS email_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  email_type VARCHAR(50) NOT NULL, -- delivery_completed, maintenance_due, etc.
  recipient VARCHAR(255) NOT NULL,
  subject VARCHAR(500),
  status VARCHAR(20) NOT NULL, -- sent, failed, bounced
  error_message TEXT,
  resend_message_id VARCHAR(100),
  sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_sent (user_id, sent_at),
  INDEX idx_status (status)
);
